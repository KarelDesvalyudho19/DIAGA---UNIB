// Dijalankan sebelum halaman digambar agar tidak ada kilatan tema yang salah.
(function () {
  var root = document.documentElement;
  root.classList.add('js');
  try {
    var saved = localStorage.getItem('diaga-theme');
    if (saved === 'light' || saved === 'dark') root.setAttribute('data-theme', saved);
  } catch (e) {
    /* storage tidak tersedia, ikuti pengaturan sistem */
  }
})();
