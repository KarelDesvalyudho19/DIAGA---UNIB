// Warna dibaca dari CSS variables (src/styles/tokens.css) supaya
// tema gelap/terang cukup mengganti variabel, bukan kelas.
const c = (name) => `rgb(var(--${name}) / <alpha-value>)`;

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./*.html', './src/**/*.{js,html}'],
  theme: {
    extend: {
      colors: {
        bg: c('bg'),
        surface: c('surface'),
        raised: c('raised'),
        ink: c('ink'),
        muted: c('muted'),
        gold: c('gold'),
        'gold-ink': c('gold-ink'),
        'gold-deep': c('gold-deep'),
        emerald: c('emerald'),
        line: c('line'),
      },
      fontFamily: {
        display: ['Cinzel', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
        rejang: ['"Noto Sans Rejang"', '"Noto Sans"', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
