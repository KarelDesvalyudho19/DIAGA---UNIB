# Pemetaan ke kriteria penilaian RAFATECH 2026

Tema: APEX, AI Powered Experience for the Web.

## Syarat lomba

| Syarat                             | Status                                                                                                                 | Di mana                                                                |
| ---------------------------------- | ---------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| Minimal 3 halaman fungsional       | 6 halaman + 404                                                                                                        | `index`, `belajar`, `pemandu-ai`, `batik`, `sentra-kreatif`, `tentang` |
| Minimal 3 fitur interaktif         | 5 fitur                                                                                                                | konverter, galeri, Pemandu AI, kuis, generator batik (plus lightbox)   |
| Responsif desktop dan mobile       | Diuji di Chrome headless pada 360 dan 1440 px (tanpa overflow). **Belum diuji di HP sungguhan, Safari, atau Firefox.** | Tailwind, grid fleksibel, `e2e/check.mjs`                              |
| Teknologi web modern               | Vite, ES modules, Tailwind, View Transitions                                                                           | `vite.config.js`                                                       |
| Link source code + improvement log | Siap                                                                                                                   | repo, `CHANGELOG.md`, bagian Catatan perubahan di `/tentang.html`      |

## Tahap proposal

| Kriteria (bobot)                     | Bukti                                                                                                                                                     |
| ------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Feasibility dan technical demo (35%) | Demo berjalan tanpa AI sekalipun (mode offline). Parser diuji dengan unit test. Fungsi server diuji dengan penyedia palsu. Lihat `docs/DEMO.md`.          |
| Inovasi dan kreativitas (25%)        | Pemandu AI berbasis data kurasi yang menyebut sumber dan menolak menebak. Konverter suku kata dengan aturan di data. Alur cerita belajar, batik, perajin. |
| Kualitas proposal (20%)              | `docs/PROPOSAL-NOTES.md` sebagai kerangka. Data masalah masih harus diisi tim.                                                                            |
| Potensi impact (15%)                 | Menghubungkan pembelajaran aksara dengan perajin nyata (Arumbatik Roemah). Klaim dampak terukur belum ada.                                                |

## Tahap final

| Kriteria (bobot)                     | Bukti                                                                                                                                                                                      |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Functionality (25%)                  | 5 fitur inti, 88 test otomatis + 26 pemeriksaan di peramban, fallback offline, penanganan error di chat dan penyimpanan.                                                                   |
| Design dan UX (20%)                  | Lighthouse Accessibility 100 di halaman yang diukur, tema gelap/terang, kontras dihitung, keyboard dan layar sentuh, `prefers-reduced-motion`, skip link, dialog dengan focus trap bawaan. |
| Technical implementation (20%)       | Multi-page Vite, partial dirender saat build, retrieval BM25 dipakai bersama server dan klien, CSP ketat di `vercel.json`, kunci API hanya di server, rate limit per IP.                   |
| Innovation dan creativity (15%)      | Lihat bagian proposal. Generator batik dengan motif buatan sendiri.                                                                                                                        |
| Presentation dan communication (10%) | Skrip 3 dan 5 menit di `docs/DEMO.md`, mode `?demo=1`.                                                                                                                                     |
| Project management (10%)             | Commit per fase, `CHANGELOG.md`, `TODO.md` yang jujur soal yang belum selesai.                                                                                                             |
