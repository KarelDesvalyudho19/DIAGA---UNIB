# Skrip demo

Buka situs dengan `?demo=1` di alamatnya (mis. `/?demo=1`). Konverter terisi "Rejang Lebong" dan chat terisi satu pertanyaan.

Siapkan sebelum mulai: tab Beranda, tab Pemandu, tab Batik. Cek koneksi. Kalau ragu, tidak masalah: chat punya mode offline.

## Versi 3 menit (demo prototipe)

| Waktu | Yang ditunjukkan                   | Yang diucapkan (garis besar)                                                                                  |
| ----- | ---------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| 0:00  | Beranda, mini-konverter            | Masalahnya satu kalimat: aksara Kaganga makin jarang dipakai. Ketik satu nama, aksaranya langsung muncul.     |
| 0:30  | Belajar, konverter "Rejang Lebong" | Kata dipecah jadi suku kata, tiap huruf ada kode Unicode-nya. Buka satu huruf di galeri.                      |
| 1:10  | Pemandu AI                         | Tanyakan "Apa itu batik Kaganga?". Buka "Dasar jawaban". Lalu tanyakan hal di luar topik: ia menolak menebak. |
| 2:00  | Batik, generator                   | Ketik nama, ganti warna, tekan unduh.                                                                         |
| 2:40  | Sentra Kreatif                     | Aksara sampai ke perajin nyata. Tutup dengan ajakan.                                                          |

Cadangan bila internet putus: lanjutkan saja. Tunjukkan lencana "Mode offline" sebagai fitur, bukan kegagalan.

## Versi 5 menit

Tambahkan setelah Pemandu:

- **Kuis (30 dtk):** jawab satu soal salah dengan sengaja, tunjukkan penjelasannya dan progres per huruf.
- **Tentang (60 dtk):** diagram arsitektur, lalu bagian Etika dan Keterbatasan. Sebut terus terang bahwa ejaan masih divalidasi narasumber.
- **Tema terang (10 dtk):** klik tombol tema.

## Pertanyaan yang mungkin ditanyakan juri

- _Bagaimana AI tidak mengarang?_ Ia hanya menjawab dari data kurasi, menyebut sumber, dan menolak bila datanya tidak ada. Data yang belum terverifikasi ditandai.
- _Kalau AI mati?_ Mode offline.
- _Apakah ejaannya benar?_ Belum divalidasi penuh. Aturannya ada di satu file data agar mudah dikoreksi narasumber.
