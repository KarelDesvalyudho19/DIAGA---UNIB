# Arsitektur DIAGA

## Gambaran

Situs statis multi-halaman (Vite) di Vercel, ditambah satu fungsi serverless `api/chat.js`.

```
Peramban ──POST /api/chat──> Fungsi (validasi, batas per IP)
                                 │ cari 3-4 entri (BM25)
                                 ▼
                            knowledge.json ──> prompt sistem ──> Penyedia AI (stream)
Peramban <──SSE: sources, delta, done──────────────────────────────┘

Jika fungsi gagal / kena batas / tidak ada kunci:
Peramban ──> salinan knowledge.json di bundel ──> jawaban lokal + lencana "Mode offline"
```

## Keputusan dan alasannya

- **Aturan aksara di `aksara.json`, bukan di kode.** Ejaan Rejang harus divalidasi narasumber. Koreksi cukup mengubah data, tanpa menyentuh parser.
- **BM25, bukan embedding.** Basis pengetahuan kecil dan kurasi. BM25 tanpa layanan tambahan, bisa jalan di server dan di peramban dengan kode yang sama (`src/modules/retrieval.js`), dan mudah dijelaskan. Ditambah syarat cakupan kata supaya satu kata yang kebetulan cocok tidak memunculkan jawaban ngawur.
- **Mode offline.** Demo lewat Zoom bisa kena koneksi buruk atau kuota AI habis. Klien menjawab dari data lokal dan mengatakannya terang-terangan.
- **Adapter penyedia lewat env** (`AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL`). Tersedia Anthropic dan Gemini. Gemini sengaja tanpa model bawaan karena nama model cepat usang.
- **Partial dirender saat build** (plugin di `vite.config.js`). Header, footer, ubin galeri, dan changelog tetap terbaca tanpa JavaScript.
- **`<dialog>` bawaan** untuk panel detail dan lightbox: focus trap dan Escape ditangani peramban.
- **Tanpa CDN.** Font dan aset dihosting sendiri sehingga CSP bisa ketat (`default-src 'self'`).

## Pertahanan di fungsi chat

- Input maksimal 500 karakter, riwayat maksimal 6 pesan dan hanya peran user/assistant.
- Batas 20 permintaan per menit per IP (di memori; cukup untuk prototipe, tidak dibagi antarinstans).
- Konteks dan pesan pengguna diperlakukan sebagai data di prompt sistem (perlawanan terhadap prompt injection, bukan jaminan).
- Kesalahan penyedia tidak diteruskan ke klien. Percakapan tidak disimpan.

## Keterbatasan yang diketahui

- Adapter Anthropic dan Gemini **belum diuji terhadap API sungguhan** (tidak ada kunci saat pengembangan). Yang sudah dicek: bentuk request Gemini sesuai dokumentasi Google (endpoint `v1beta/models/{model}:streamGenerateContent?alt=sse`, `systemInstruction`, header `x-goog-api-key`), dan seluruh jalur streaming dari fungsi server ke UI diuji dengan penyedia tiruan (`e2e/stream.mjs`). Bentuk request Anthropic ditulis dari pengetahuan saya dan tidak dicek ulang ke dokumentasi.
- Model Gemini wajib diisi lewat `AI_MODEL`. Model 2.5 dijadwalkan dimatikan Oktober 2026, dan halaman dokumentasi Google sendiri menyebut pengganti yang berbeda-beda, jadi cek daftar terbaru saat deploy.
- Rate limit di memori tidak akurat bila Vercel menjalankan banyak instans.
- Tidak ada adapter Netlify.
- Stemming bahasa Indonesia sangat sederhana.
