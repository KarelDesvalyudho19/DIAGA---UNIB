# Catatan untuk proposal

Kerangka saja. Angka dan kutipan harus diisi tim dari sumber yang bisa dicek.

## Masalah

- Aksara Kaganga makin jarang dipakai dan dipelajari.
- Batik tulis Kaganga tergeser batik cap. (Sumber saat ini lemah: blog 2009. Cari yang lebih kuat.)
- TODO: data pendukung (jumlah penutur, perajin, sekolah yang mengajarkan aksara).

## Solusi

Museum digital yang mengalirkan pengguna dari belajar aksara, ke melihatnya di batik, ke terhubung dengan perajin. Pemandu AI menemani, berbasis data kurasi.

## Yang membedakan

- AI yang menyebut sumber dan mau bilang "belum ada datanya".
- Konverter yang memecah suku kata dan menunjukkan kode Unicode, bisa dikoreksi lewat data.
- Tetap berjalan tanpa AI.

## Dampak yang wajar diklaim

- Mempermudah orang mengenal dan mencoba menulis aksara.
- Mengarahkan perhatian ke perajin.
- **Jangan** mengklaim pelestarian terukur sebelum ada data pemakaian.

## Kelayakan

- Sudah berjalan: 88 test otomatis.
- Risiko: validasi ejaan, kualitas sumber, kuota AI.
