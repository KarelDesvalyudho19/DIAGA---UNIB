// Adapter penyedia AI. Dipilih lewat env AI_PROVIDER. Kunci hanya dibaca di server.
// Belum diuji terhadap API sungguhan (tidak ada kunci saat pengembangan).

// Hanya Anthropic yang punya model bawaan. Untuk Gemini sengaja tanpa bawaan: nama model
// cepat berganti (seri 2.5 dijadwalkan dimatikan Oktober 2026), jadi AI_MODEL wajib diisi.
const DEFAULT_MODEL = {
  anthropic: 'claude-haiku-4-5-20251001',
};

/** Membuka permintaan streaming. Mengembalikan { response, textOf } atau melempar error. */
export async function openProvider({
  provider,
  apiKey,
  model,
  system,
  messages,
  maxTokens,
  signal,
}) {
  const name = provider || 'anthropic';
  const useModel = model || DEFAULT_MODEL[name];
  if (!apiKey || !useModel) throw new Error('konfigurasi AI belum lengkap');

  if (name === 'anthropic') {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      signal,
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: useModel,
        max_tokens: maxTokens,
        system,
        messages,
        stream: true,
      }),
    });
    return {
      response,
      textOf: (evt) => (evt.type === 'content_block_delta' ? (evt.delta?.text ?? '') : ''),
    };
  }

  if (name === 'gemini') {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(useModel)}:streamGenerateContent?alt=sse`;
    const response = await fetch(url, {
      method: 'POST',
      signal,
      headers: { 'content-type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: messages.map((m) => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: m.content }],
        })),
        generationConfig: { maxOutputTokens: maxTokens },
      }),
    });
    return {
      response,
      textOf: (evt) =>
        (evt.candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? '').join(''),
    };
  }

  throw new Error('penyedia AI tidak dikenal');
}

/** Membaca aliran SSE dan menghasilkan objek JSON dari tiap baris "data:". */
export async function* readSse(response) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let cut;
    while ((cut = buffer.indexOf('\n\n')) !== -1) {
      const block = buffer.slice(0, cut);
      buffer = buffer.slice(cut + 2);
      for (const line of block.split('\n')) {
        if (!line.startsWith('data:')) continue;
        const raw = line.slice(5).trim();
        if (!raw || raw === '[DONE]') continue;
        try {
          yield JSON.parse(raw);
        } catch {
          /* potongan tidak utuh, abaikan */
        }
      }
    }
  }
}
