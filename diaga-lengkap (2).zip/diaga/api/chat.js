// Fungsi serverless (format Vercel). Alurnya: validasi -> batas per IP -> cari konteks
// -> panggil penyedia AI dengan streaming -> teruskan ke klien sebagai SSE.
// Percakapan tidak disimpan. Kunci API hanya dari environment server.
import { buildSystemPrompt, clientIp, rateLimited, retrieve, validate } from './_core.js';
import { openProvider, readSse } from './_providers.js';

const MAX_TOKENS = 450;
const TIMEOUT_MS = 20_000;

function json(res, status, payload) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(payload));
}

const sse = (res, event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return json(res, 405, { error: 'Metode tidak diizinkan.' });
  }
  if (rateLimited(clientIp(req))) {
    res.setHeader('Retry-After', '60');
    return json(res, 429, { error: 'Terlalu banyak permintaan. Coba lagi sebentar.' });
  }

  const input = validate(req.body);
  if (!input.ok) return json(res, 400, { error: input.error });

  const entries = retrieve(input.message);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const { response, textOf } = await openProvider({
      provider: process.env.AI_PROVIDER,
      apiKey: process.env.AI_API_KEY,
      model: process.env.AI_MODEL,
      system: buildSystemPrompt(entries),
      messages: [...input.history, { role: 'user', content: input.message }],
      maxTokens: MAX_TOKENS,
      signal: controller.signal,
    });
    if (!response.ok || !response.body) {
      // Detail dari penyedia sengaja tidak diteruskan ke klien.
      return json(res, 502, { error: 'Layanan AI sedang tidak tersedia.' });
    }

    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    sse(res, 'sources', entries);
    for await (const evt of readSse(response)) {
      const text = textOf(evt);
      if (text) sse(res, 'delta', { t: text });
    }
    sse(res, 'done', {});
    res.end();
  } catch {
    if (!res.headersSent) return json(res, 502, { error: 'Layanan AI sedang tidak tersedia.' });
    sse(res, 'error', { error: 'Aliran terputus.' });
    res.end();
  } finally {
    clearTimeout(timer);
  }
}
