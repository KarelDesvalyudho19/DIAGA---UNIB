# Uji peramban dan Lighthouse

Terpisah dari proyek utama karena dependensinya besar (Chromium ikut terunduh lewat npm).

```bash
# terminal 1, di root proyek
npm run build && npx vite preview --port 4173

# terminal 2
cd e2e && npm install
npm run check        # konsol, request gagal, overflow horizontal, 7 halaman x 2 ukuran layar
npm run func         # 26 pemeriksaan fitur: konverter, galeri, kuis, chat offline, batik, tema, tanpa JS
npm run lighthouse   # skor 4 kategori per halaman
```

Uji jalur AI dari ujung ke ujung (penyedia tiruan, tanpa kunci):

```bash
# di root: npm run build
node e2e/stream-server.mjs &      # menyajikan dist/ + api/chat.js di port 4174
cd e2e && npm run stream
```

Untuk menguji situs yang sudah di-deploy: `BASE=https://alamat-kamu.vercel.app npm run func`.

Catatan: pemeriksaan ini memakai Chrome headless (build sparticuz), bukan Safari atau Firefox, dan bukan HP sungguhan. Lighthouse dijalankan dengan emulasi mobile dan throttling simulasi.
