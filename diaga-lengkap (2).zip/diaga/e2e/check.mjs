import chromium from '@sparticuz/chromium';
import puppeteer from 'puppeteer-core';
const base = (process.env.BASE ?? 'http://localhost:4173') + '';
const pages = [
  '/',
  '/belajar.html',
  '/pemandu-ai.html',
  '/batik.html',
  '/sentra-kreatif.html',
  '/tentang.html',
  '/404.html',
];
const b = await puppeteer.launch({
  args: chromium.args,
  executablePath: await chromium.executablePath(),
  headless: 'shell',
});
const problems = [];
for (const [w, h, label] of [
  [360, 800, 'mobile'],
  [1440, 900, 'desktop'],
]) {
  for (const p of pages) {
    const page = await b.newPage();
    await page.setViewport({ width: w, height: h });
    const errs = [];
    page.on('console', (m) => {
      if (['error', 'warning'].includes(m.type())) errs.push(`${m.type()}: ${m.text()}`);
    });
    page.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
    page.on('requestfailed', (r) => errs.push('requestfailed: ' + r.url()));
    page.on('response', (r) => {
      if (r.status() >= 400) errs.push(`HTTP ${r.status()}: ${r.url()}`);
    });
    await page.goto(base + p, { waitUntil: 'networkidle0' });
    const m = await page.evaluate(() => ({
      overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth,
      wide: [...document.querySelectorAll('body *')]
        .filter(
          (e) =>
            e.getBoundingClientRect().right > innerWidth + 1 &&
            !e.closest('.overflow-x-auto, dialog, .chat-widget'),
        )
        .slice(0, 3)
        .map((e) => e.tagName + '.' + String(e.className).slice(0, 40)),
    }));
    const tag = `${label} ${p}`;
    if (m.overflow > 0)
      problems.push(`${tag}: overflow horizontal ${m.overflow}px ${JSON.stringify(m.wide)}`);
    for (const e of errs) problems.push(`${tag}: ${e}`);
    if (['/', '/belajar.html', '/batik.html'].includes(p))
      await page.screenshot({
        path: `shot-${label}-${p.replace(/\W/g, '') || 'index'}.png`,
        fullPage: false,
      });
    await page.close();
  }
}
console.log(
  problems.length ? problems.join('\n') : 'TIDAK ADA MASALAH (konsol, request, overflow)',
);
await b.close();
