import chromium from '@sparticuz/chromium';
import puppeteer from 'puppeteer-core';
import lighthouse from 'lighthouse';
const b = await puppeteer.launch({
  args: chromium.args,
  executablePath: await chromium.executablePath(),
  headless: 'shell',
});
const port = new URL(b.wsEndpoint()).port;
const targets = process.argv.slice(2);
for (const path of targets) {
  const r = await lighthouse((process.env.BASE ?? 'http://localhost:4173') + '' + path, {
    port: Number(port),
    output: 'json',
    logLevel: 'error',
    onlyCategories: ['performance', 'accessibility', 'best-practices', 'seo'],
  });
  const c = r.lhr.categories;
  const line = Object.values(c)
    .map((x) => `${x.id}:${Math.round(x.score * 100)}`)
    .join('  ');
  const m = r.lhr.audits;
  console.log(
    `${path.padEnd(20)} ${line}  LCP:${m['largest-contentful-paint'].displayValue} CLS:${m['cumulative-layout-shift'].displayValue} TBT:${m['total-blocking-time'].displayValue}`,
  );
  const bad = Object.values(r.lhr.audits).filter(
    (a) =>
      a.score !== null &&
      a.score < 0.9 &&
      a.scoreDisplayMode !== 'informative' &&
      a.scoreDisplayMode !== 'manual' &&
      a.weight !== 0,
  );
  const fails = Object.values(r.lhr.audits).filter(
    (a) => a.score === 0 && a.scoreDisplayMode === 'binary',
  );
  for (const a of fails) console.log('   GAGAL:', a.id, '-', a.title);
}
await b.close();
