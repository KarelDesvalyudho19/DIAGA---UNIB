import chromium from '@sparticuz/chromium';
import puppeteer from 'puppeteer-core';
const b = await puppeteer.launch({
  args: chromium.args,
  executablePath: await chromium.executablePath(),
  headless: 'shell',
});
const results = [];
const ok = (name, cond, extra = '') =>
  console.log(`${cond ? 'OK  ' : 'GAGAL'} ${name}${extra ? ' :: ' + extra : ''}`);
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
async function open(path, w = 1440, h = 900, scheme = 'dark') {
  const page = await b.newPage();
  await page.setViewport({ width: w, height: h });
  await page.emulateMediaFeatures([{ name: 'prefers-color-scheme', value: scheme }]);
  page._errs = [];
  page.on('pageerror', (e) => page._errs.push(e.message));
  page.on(
    'console',
    (m) => m.type() === 'error' && !m.text().includes('404') && page._errs.push(m.text()),
  );
  await page.goto((process.env.BASE ?? 'http://localhost:4173') + '' + path, {
    waitUntil: 'networkidle0',
  });
  return page;
}

// --- Font Rejang benar-benar dimuat & dirender (bukan kotak kosong)
let page = await open('/belajar.html');
const font = await page.evaluate(async () => {
  await document.fonts.load('48px "Noto Sans Rejang"', '\uA930');
  return {
    check: document.fonts.check('48px "Noto Sans Rejang"', '\uA930'),
    loaded: [...document.fonts].filter((f) => f.family.includes('Rejang') && f.status === 'loaded')
      .length,
  };
});
ok('font Rejang termuat', font.check && font.loaded >= 1, JSON.stringify(font));

// --- Konverter: ketik, rincian suku kata, unmapped
await page.$eval('#conv-input', (e) => e.select());
await page.type('#conv-input', 'Rejang Lebong');
await wait(400);
const conv = await page.evaluate(() => ({
  out: document.querySelector('[data-conv-output]').textContent,
  rows: document.querySelectorAll('[data-conv-breakdown] li').length,
}));
ok(
  'konverter "Rejang Lebong" menghasilkan aksara & rincian',
  conv.out === '\uA93D\uA949\uA93A\uA94F \uA93E\uA949\uA937\uA94B\uA94F' && conv.rows === 4,
  JSON.stringify({ rows: conv.rows, out: conv.out }),
);
await page.$eval('#conv-input', (e) => e.select());
await page.type('#conv-input', 'Rafflesia');
await wait(400);
ok(
  'huruf tanpa padanan diberi peringatan',
  (await page.$eval('[data-conv-notice]', (e) => e.textContent)).includes('f'),
);

// --- Galeri: buka dialog, navigasi panah, Escape, fokus kembali
await page.click('[data-letter="0"]');
await wait(200);
let d = await page.evaluate(() => ({
  open: document.querySelector('[data-detail]').open,
  latin: document.querySelector('[data-d="latin"]').textContent,
}));
ok('galeri membuka panel detail huruf pertama', d.open && d.latin === 'ka', JSON.stringify(d));
await page.keyboard.press('ArrowRight');
ok(
  'panah kanan pindah ke huruf berikutnya',
  (await page.$eval('[data-d="latin"]', (e) => e.textContent)) === 'ga',
);
await page.keyboard.press('Escape');
await wait(150);
d = await page.evaluate(() => ({
  open: document.querySelector('[data-detail]').open,
  focus: document.activeElement?.dataset?.letter,
}));
ok('Escape menutup dan fokus kembali ke ubin', !d.open && d.focus === '0', JSON.stringify(d));

// --- Kuis: jawab, skor, persistensi lewat reload
await page.evaluate(() => document.getElementById('kuis').scrollIntoView());
await page.click('[data-option]');
await wait(150);
const q1 = await page.evaluate(() => ({
  fb: document.querySelector('[data-q="feedback"]').textContent,
  sc: document.querySelector('[data-q="score"]').textContent,
}));
ok(
  'kuis memberi umpan balik dan mencatat skor',
  /Benar|Belum tepat/.test(q1.fb) && /\/ 1$/.test(q1.sc),
  JSON.stringify(q1),
);
await page.reload({ waitUntil: 'networkidle0' });
ok(
  'progres kuis bertahan setelah reload',
  (await page.$eval('[data-q="score"]', (e) => e.textContent)).endsWith('/ 1'),
);
ok('belajar: tidak ada error JS', page._errs.length === 0, page._errs.join(' | '));
await page.close();

// --- Chat: /api/chat tidak ada di preview -> harus jatuh ke mode offline
page = await open('/pemandu-ai.html');
await page.click('[data-chat-example="Di mana alamat Arumbatik Roemah?"]');
await wait(800);
const chat = await page.evaluate(() => ({
  log: document.querySelector('[data-chat-log]').textContent,
  badge: !document.querySelector('[data-chat-badge]').hidden,
  src: document.querySelector('details summary')?.textContent,
}));
ok(
  'chat: fallback offline menjawab dari data',
  chat.log.includes('Batu Galing') && chat.badge && /Dasar jawaban/.test(chat.src ?? ''),
  chat.src,
);
await page.type('[data-chat-input]', 'siapa presiden amerika');
await page.keyboard.press('Enter');
await wait(800);
ok(
  'chat: menolak menebak di luar topik',
  (await page.$eval('[data-chat-log]', (e) => e.textContent)).includes(
    'belum punya data yang cukup',
  ),
);
ok('chat: tidak ada error JS', page._errs.length === 0, page._errs.join(' | '));
await page.close();

// --- Widget mengambang di halaman lain
page = await open('/tentang.html');
await page.click('[data-chat-widget] a');
await wait(300);
ok(
  'widget chat terbuka & terpasang',
  await page.evaluate(
    () =>
      !document.querySelector('.chat-widget-panel').hidden &&
      !!document.querySelector('.chat-widget-panel [data-chat-input]'),
  ),
);
await page.keyboard.press('Escape');
ok(
  'Escape menutup widget',
  await page.evaluate(() => document.querySelector('.chat-widget-panel').hidden),
);
ok(
  'changelog tampil di Tentang',
  await page.evaluate(() => document.querySelectorAll('#changelog li').length > 5),
);
await page.close();

// --- Generator batik: kanvas terisi, unduh menghasilkan PNG valid
page = await open('/batik.html');
const px = await page.evaluate(() => {
  const c = document.querySelector('[data-batik-canvas]');
  const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
  const colors = new Set();
  for (let i = 0; i < d.length; i += 4 * 997) colors.add(d[i] + ',' + d[i + 1] + ',' + d[i + 2]);
  return { w: c.width, colors: colors.size };
});
ok('kanvas batik tergambar (bukan kosong)', px.w === 1200 && px.colors > 3, JSON.stringify(px));
await page.click('input[value="nila"]');
await wait(200);
const blobOk = await page.evaluate(async () => {
  const c = document.querySelector('[data-batik-canvas]');
  const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
  const head = new Uint8Array(await blob.arrayBuffer()).slice(0, 4);
  return { size: blob.size, png: [...head].join() === '137,80,78,71' };
});
ok(
  'unduhan PNG valid dan berukuran wajar',
  blobOk.png && blobOk.size > 20000,
  JSON.stringify(blobOk),
);
await page.evaluate(() => document.getElementById('koleksi').scrollIntoView());
await page.click('[data-photo="6"]');
await wait(200);
const lb = await page.evaluate(() => ({
  open: document.querySelector('[data-lightbox]').open,
  cat: document.querySelector('[data-l="cat"]').textContent,
}));
ok(
  'lightbox membuka songket sebagai Tekstil Bengkulu',
  lb.open && lb.cat === 'Tekstil Bengkulu',
  JSON.stringify(lb),
);
await page.keyboard.press('Escape');
ok('batik: tidak ada error JS', page._errs.length === 0, page._errs.join(' | '));
await page.close();

// --- Tema & menu mobile
page = await open('/', 360, 800, 'dark');
const hdr = await page.evaluate(
  () => document.querySelector('.site-header').getBoundingClientRect().height,
);
ok('header mobile satu baris', hdr < 70, Math.round(hdr) + 'px');
await page.click('[data-menu-toggle]');
ok(
  'menu mobile terbuka (aria-expanded)',
  await page.evaluate(
    () =>
      document.querySelector('[data-menu-toggle]').getAttribute('aria-expanded') === 'true' &&
      getComputedStyle(document.getElementById('nav-list')).display === 'flex',
  ),
);
await page.click('[data-menu-toggle]');
await page.click('[data-theme-toggle]');
const th = await page.evaluate(() => ({
  t: document.documentElement.dataset.theme,
  s: localStorage.getItem('diaga-theme'),
  bg: getComputedStyle(document.body).backgroundColor,
}));
ok(
  'tema berganti dan tersimpan',
  th.t === 'light' && th.s === 'light' && th.bg.includes('246'),
  JSON.stringify(th),
);
await page.reload({ waitUntil: 'networkidle0' });
ok(
  'tema bertahan setelah reload tanpa kilatan',
  await page.evaluate(() => document.documentElement.dataset.theme === 'light'),
);
await page.close();

// --- Mode demo
page = await open('/?demo=1');
ok(
  '?demo=1 mengisi konverter',
  (await page.$eval('#conv-input', (e) => e.value)) === 'Rejang Lebong',
);
await page.close();
page = await open('/pemandu-ai.html?demo=1');
ok(
  '?demo=1 mengisi pertanyaan chat',
  (await page.$eval('[data-chat-input]', (e) => e.value)) === 'Apa itu batik Kaganga?',
);
await page.close();

// --- Tanpa JavaScript: konten inti tetap terbaca
const np = await b.newPage();
await np.setJavaScriptEnabled(false);
await np.setViewport({ width: 360, height: 800 });
await np.goto((process.env.BASE ?? 'http://localhost:4173') + '/belajar.html', {
  waitUntil: 'load',
});
const nojs = await np.evaluate(() => ({
  nav: getComputedStyle(document.getElementById('nav-list')).display,
  glyph: document.querySelector('[data-conv-output]').textContent.length,
  tiles: document.querySelectorAll('[data-letter]').length,
}));
ok(
  'tanpa JS: navigasi terlihat, aksara & galeri tetap ada',
  nojs.nav !== 'none' && nojs.glyph > 3 && nojs.tiles === 23,
  JSON.stringify(nojs),
);
await np.close();

await b.close();
