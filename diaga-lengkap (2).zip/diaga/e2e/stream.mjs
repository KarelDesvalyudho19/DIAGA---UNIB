// Menguji jalur AI dari ujung ke ujung: SSE dari fungsi server -> UI chat di peramban.
import chromium from '@sparticuz/chromium';
import puppeteer from 'puppeteer-core';

const base = process.env.BASE ?? 'http://localhost:4174';
const ok = (name, cond, extra = '') =>
  console.log(`${cond ? 'OK  ' : 'GAGAL'} ${name}${extra ? ' :: ' + extra : ''}`);
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const b = await puppeteer.launch({
  args: chromium.args,
  executablePath: await chromium.executablePath(),
  headless: 'shell',
});

async function ask(mode, question) {
  await fetch(`${base}/__mode?m=${mode}`);
  const page = await b.newPage();
  await page.goto(`${base}/pemandu-ai.html`, { waitUntil: 'networkidle0' });
  await page.type('[data-chat-input]', question);
  await page.keyboard.press('Enter');
  const samples = [];
  for (let i = 0; i < 14; i++) {
    await wait(150);
    samples.push(
      await page.evaluate(
        () =>
          [...document.querySelectorAll('[data-chat-log] .whitespace-pre-wrap')].at(-1)
            ?.textContent ?? '',
      ),
    );
  }
  const end = await page.evaluate(() => ({
    badgeHidden: document.querySelector('[data-chat-badge]').hidden,
    sources: document.querySelector('details summary')?.textContent ?? '',
    sourceTitles: [...document.querySelectorAll('details li p.font-semibold')].map(
      (e) => e.textContent,
    ),
    copy: !!document.querySelector('[data-chat-log] button'),
  }));
  await page.close();
  return { samples, end };
}

const good = await ask('ok', 'Apa itu batik Kaganga?');
const distinct = [...new Set(good.samples.filter((s) => s.length > 0))];
const growing = distinct.filter((s) => s.startsWith('Batik')).length;
ok(
  'jawaban AI muncul bertahap (streaming), bukan sekaligus',
  growing >= 3,
  `${growing} tahap: ${JSON.stringify(distinct.slice(0, 4))}`,
);
ok(
  'teks akhir utuh dari aliran server',
  good.samples.at(-1) === 'Batik Kaganga lahir di Tanah Rejang [1].',
  good.samples.at(-1),
);
ok('lencana offline tidak muncul saat AI berhasil', good.end.badgeHidden);
ok(
  'sumber dari server ditampilkan',
  /Dasar jawaban \(\d+\)/.test(good.end.sources),
  JSON.stringify(good.end.sourceTitles),
);
ok('tombol salin ada', good.end.copy);

const bad = await ask('error', 'Di mana alamat Arumbatik Roemah?');
ok(
  'penyedia AI error -> fallback offline menjawab dengan data',
  bad.samples.at(-1).includes('Batu Galing') && !bad.end.badgeHidden,
  bad.samples.at(-1).slice(0, 60),
);

// Batas 20 permintaan per menit per IP: permintaan ke-21 harus 429 dan UI tetap menjawab (offline).
await fetch(`${base}/__mode?m=ok`);
const codes = [];
for (let i = 0; i < 22; i++) {
  const r = await fetch(`${base}/api/chat`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ message: 'halo batik' }),
  });
  codes.push(r.status);
  await r.text();
}
ok(
  'rate limit: 429 setelah batas, dengan Retry-After',
  codes.includes(429) && codes.indexOf(429) >= 15,
  `${codes.filter((c) => c === 200).length} x 200, ${codes.filter((c) => c === 429).length} x 429`,
);
const limited = await ask('ok', 'Apa itu batik besurek?');
ok(
  'saat kena batas, UI tetap menjawab lewat mode offline',
  !limited.end.badgeHidden && limited.samples.at(-1).length > 20,
  limited.samples.at(-1).slice(0, 50),
);

const r400 = await fetch(`${base}/api/chat`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ message: 'x'.repeat(501) }),
});
ok(
  'input >500 karakter ditolak 400 (atau 429 bila batas sudah habis)',
  [400, 429].includes(r400.status),
  String(r400.status),
);
await b.close();
