// Server uji: menyajikan dist/ dan menjalankan api/chat.js apa adanya lewat HTTP sungguhan.
// Penyedia AI diganti tiruan (fetch ke api.anthropic.com dicegat) agar bisa menguji streaming
// dari fungsi server sampai ke peramban tanpa kunci API.
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = resolve(import.meta.dirname, '../dist');
const handler = (await import(pathToFileURL(resolve(import.meta.dirname, '../api/chat.js'))))
  .default;
process.env.AI_PROVIDER = 'anthropic';
process.env.AI_API_KEY = 'kunci-tiruan';

let mode = 'ok'; // ok | error
const realFetch = globalThis.fetch;
const enc = new TextEncoder();
globalThis.fetch = async (url, init) => {
  if (!String(url).startsWith('https://api.anthropic.com/')) return realFetch(url, init);
  if (mode === 'error') return { ok: false, status: 500, body: null };
  const words = ['Batik', ' Kaganga', ' lahir', ' di', ' Tanah', ' Rejang', ' [1].'];
  return {
    ok: true,
    body: new ReadableStream({
      async start(c) {
        for (const w of words) {
          c.enqueue(
            enc.encode(
              `event: content_block_delta\ndata: ${JSON.stringify({ type: 'content_block_delta', delta: { text: w } })}\n\n`,
            ),
          );
          await new Promise((r) => setTimeout(r, 250));
        }
        c.close();
      },
    }),
  };
};

const types = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript',
  '.css': 'text/css',
  '.svg': 'image/svg+xml',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.txt': 'text/plain',
};

http
  .createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x');
    if (url.pathname === '/__mode') {
      mode = url.searchParams.get('m');
      return res.end('ok');
    }
    if (url.pathname === '/api/chat') {
      let raw = '';
      for await (const chunk of req) raw += chunk;
      req.body = raw ? JSON.parse(raw) : undefined;
      return handler(req, res);
    }
    let path = url.pathname === '/' ? '/index.html' : url.pathname;
    try {
      const file = await readFile(join(root, path));
      res.setHeader('Content-Type', types[extname(path)] ?? 'application/octet-stream');
      res.end(file);
    } catch {
      res.statusCode = 404;
      res.end('tidak ada');
    }
  })
  .listen(Number(process.env.PORT ?? 4174), () => console.log('siap'));
