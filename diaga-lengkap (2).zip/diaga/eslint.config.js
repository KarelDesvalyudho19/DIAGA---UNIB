import js from '@eslint/js';
import globals from 'globals';

export default [
  { ignores: ['dist/', 'node_modules/', 'public/', 'e2e/'] },
  js.configs.recommended,
  {
    files: ['src/**/*.js'],
    languageOptions: { globals: globals.browser, sourceType: 'module' },
  },
  {
    files: ['tests/**/*.js', '*.config.js', 'api/**/*.js'],
    languageOptions: { globals: { ...globals.node, ...globals.browser }, sourceType: 'module' },
  },
];
