import { describe, it, expect } from 'vitest';
import { convertWord, convertText } from '../src/modules/converter.js';

// Ubah hasil parser jadi daftar kode heksadesimal agar mudah dibandingkan.
const codes = (word, opts) =>
  convertWord(word, opts)
    .flatMap((s) => s.codes)
    .join(' ');

describe('huruf dasar dan prenasal', () => {
  it.each([
    ['ka', 'A930'],
    ['nga', 'A932'],
    ['ngga', 'A943'],
    ['mba', 'A942'],
    ['nda', 'A944'],
    ['nya', 'A93B'],
    ['a', 'A946'],
  ])('%s -> %s', (latin, expected) => {
    expect(codes(latin)).toBe(expected);
  });
});

describe('tanda vokal', () => {
  it.each([
    ['ki', 'A930 A947'],
    ['ku', 'A930 A948'],
    ['ke', 'A930 A949'], // perlu validasi narasumber (pepet vs taleng)
    ['kai', 'A930 A94A'],
    ['ko', 'A930 A94B'],
    ['kau', 'A930 A94C'],
    ['keu', 'A930 A94D'],
    ['kea', 'A930 A94E'],
  ])('%s -> %s', (latin, expected) => {
    expect(codes(latin)).toBe(expected);
  });

  it('vokal di awal kata memakai huruf A', () => {
    expect(codes('i')).toBe('A946 A947');
    expect(codes('u')).toBe('A946 A948');
  });
});

describe('konsonan akhir', () => {
  it.each([
    ['kang', 'A930 A94F'],
    ['kan', 'A930 A950'],
    ['kar', 'A930 A951'],
    ['kah', 'A930 A952'],
  ])('%s -> %s (tanda konsonan)', (latin, expected) => {
    expect(codes(latin)).toBe(expected);
  });

  it('konsonan akhir lain memakai huruf + virama', () => {
    expect(codes('kak')).toBe('A930 A930 A953');
    expect(codes('kat')).toBe('A930 A933 A953');
    expect(codes('kap')).toBe('A930 A936 A953');
  });
});

describe('kata utuh', () => {
  it('bengkulu', () => {
    // be-ng ku lu
    expect(codes('bengkulu')).toBe('A937 A949 A94F A930 A948 A93E A948');
  });

  it('rejang', () => {
    // re ja-ng  (e: perlu validasi narasumber)
    expect(codes('rejang')).toBe('A93D A949 A93A A94F');
  });

  it('memecah suku kata dengan benar', () => {
    const syl = convertWord('bengkulu').map((s) => s.latin);
    expect(syl).toEqual(['beng', 'ku', 'lu']);
  });

  it('kata dengan onset prenasal di tengah', () => {
    expect(convertWord('kambing').map((s) => s.latin)).toEqual(['ka', 'mbing']);
    expect(convertWord('tinggi').map((s) => s.latin)).toEqual(['ti', 'nggi']);
  });

  it('tidak peduli huruf besar dan diakritik', () => {
    expect(codes('BENGKULU')).toBe(codes('bengkulu'));
    expect(codes('Rejang')).toBe(codes('rejang'));
  });
});

describe('karakter tanpa padanan', () => {
  it('tidak dicampur diam-diam', () => {
    const syl = convertWord('fa');
    expect(syl[0]).toMatchObject({ latin: 'f', unmapped: true });
    expect(syl[1].codes).toEqual(['A946']); // 'a' berdiri sendiri = huruf A
  });

  it('opsi pengganti mengubah f menjadi p', () => {
    expect(codes('fa', { substitute: true })).toBe('A936');
    expect(convertWord('fa', { substitute: true }).some((s) => s.unmapped)).toBe(false);
  });
});

describe('convertText', () => {
  it('menjaga spasi dan menandai karakter belum ada padanan', () => {
    const r = convertText('Rejang Lebong');
    expect(r.segments.filter((s) => s.type === 'word')).toHaveLength(2);
    expect(r.glyph.includes(' ')).toBe(true);
    expect(r.hasUnmapped).toBe(false);
    expect(convertText('Rafflesia').hasUnmapped).toBe(true);
  });
});
