import { describe, it, expect } from 'vitest';
import { changelogToHtml } from '../src/build/markdown.js';

describe('changelogToHtml', () => {
  it('membuat judul dan daftar', () => {
    const html = changelogToHtml('## [0.1.0]\n### Ditambahkan\n- Satu\n- Dua `kode`');
    expect(html).toContain('<h3');
    expect(html).toContain('<li>Satu</li>');
    expect(html).toContain('<code>kode</code>');
  });
  it('meng-escape HTML mentah', () => {
    expect(changelogToHtml('- <script>alert(1)</script>')).not.toContain('<script>');
  });
  it('hanya mengizinkan tautan http(s)', () => {
    expect(changelogToHtml('- [x](javascript:alert(1))')).not.toContain('href="javascript');
  });
});
