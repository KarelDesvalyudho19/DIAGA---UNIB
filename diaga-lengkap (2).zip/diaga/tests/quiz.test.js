import { describe, it, expect } from 'vitest';
import {
  emptyState,
  grade,
  makeQuestion,
  pickItem,
  isCorrect,
  itemsFor,
  WORDS,
} from '../src/modules/quiz-logic.js';

// Generator acak deterministik agar test stabil.
function seeded(seed = 1) {
  return () => {
    seed = (seed * 16807) % 2147483647;
    return seed / 2147483647;
  };
}

describe('kotak Leitner', () => {
  it('jawaban benar menaikkan kotak sampai maksimum 3', () => {
    let s = emptyState();
    for (let i = 0; i < 5; i++) s = grade(s, 'ka', true);
    expect(s.items.ka.box).toBe(3);
    expect(s.streak).toBe(5);
  });
  it('jawaban salah mengembalikan ke kotak 1 dan memutus streak', () => {
    let s = emptyState();
    s = grade(grade(s, 'ka', true), 'ka', true);
    s = grade(s, 'ka', false);
    expect(s.items.ka.box).toBe(1);
    expect(s.streak).toBe(0);
    expect(s.best).toBe(2);
  });
  it('butir di kotak rendah lebih sering keluar', () => {
    let s = emptyState();
    for (const id of itemsFor('bunyi-ke-huruf'))
      if (id !== 'ka') for (let i = 0; i < 3; i++) s = grade(s, id, true);
    const rng = seeded(7);
    const hits = { ka: 0, total: 0 };
    for (let i = 0; i < 400; i++) {
      hits.total++;
      if (pickItem('bunyi-ke-huruf', s, rng) === 'ka') hits.ka++;
    }
    // Peluang teoretis 5/27 (~18%), jauh di atas 1/23 (~4%) kalau semua butir setara.
    expect(hits.ka / hits.total).toBeGreaterThan(0.12);
  });
  it('tidak mengulang butir yang baru keluar', () => {
    const rng = seeded(3);
    for (let i = 0; i < 50; i++)
      expect(pickItem('bunyi-ke-huruf', emptyState(), rng, 'ka')).not.toBe('ka');
  });
});

describe('pembuatan soal', () => {
  it('pilihan ganda punya 4 opsi unik dan memuat jawaban', () => {
    for (const mode of ['bunyi-ke-huruf', 'huruf-ke-bunyi']) {
      const q = makeQuestion(mode, emptyState(), seeded(5));
      expect(q.options).toHaveLength(4);
      expect(new Set(q.options.map((o) => o.value)).size).toBe(4);
      expect(q.options.some((o) => o.value === q.answer)).toBe(true);
      expect(q.explanation.length).toBeGreaterThan(10);
    }
  });
  it('soal ketik: aksara dari kata dan jawaban tidak peka huruf besar', () => {
    const q = makeQuestion('aksara-ke-kata', emptyState(), seeded(9));
    expect(WORDS).toContain(q.answer);
    expect(q.glyph.length).toBeGreaterThan(0);
    expect(isCorrect(q, `  ${q.answer.toUpperCase()} `)).toBe(true);
    expect(isCorrect(q, 'salah')).toBe(false);
  });
  it('semua kata soal ketik bisa dikonversi tanpa huruf tanpa padanan', () => {
    for (const w of WORDS) {
      const q = makeQuestion(
        'aksara-ke-kata',
        { ...emptyState() },
        () => WORDS.indexOf(w) / WORDS.length + 0.001,
      );
      expect(q.glyph).not.toMatch(/[a-z]/);
    }
  });
});
