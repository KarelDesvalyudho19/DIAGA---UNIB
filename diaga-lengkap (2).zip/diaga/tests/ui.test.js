// @vitest-environment jsdom
import { describe, it, expect, beforeEach, vi } from 'vitest';
import { readFileSync } from 'node:fs';
import { mountChat } from '../src/modules/chat.js';
import { mountQuiz } from '../src/modules/quiz-ui.js';

const tick = () => new Promise((r) => setTimeout(r, 20));

describe('chat', () => {
  let root;
  beforeEach(() => {
    document.body.innerHTML = readFileSync('src/partials/chat.html', 'utf8');
    root = document.querySelector('[data-chat]');
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => Promise.reject(new Error('offline'))),
    );
    mountChat(root);
  });

  it('jatuh ke mode offline dan tetap menjawab dengan sumber', async () => {
    root.querySelector('[data-chat-example="Di mana alamat Arumbatik Roemah?"]').click();
    await tick();
    expect(root.querySelector('[data-chat-log]').textContent).toContain('Batu Galing');
    expect(root.querySelector('[data-chat-badge]').hidden).toBe(false);
    expect(root.querySelector('details summary').textContent).toContain('Dasar jawaban');
    expect(root.textContent).toContain('Belum terverifikasi');
  });

  it('menolak menebak untuk pertanyaan di luar data', async () => {
    root.querySelector('[data-chat-input]').value = 'siapa pemenang piala dunia 2010';
    root.querySelector('[data-chat-form]').dispatchEvent(new Event('submit', { cancelable: true }));
    await tick();
    expect(root.querySelector('[data-chat-log]').textContent).toContain(
      'belum punya data yang cukup',
    );
  });

  it('teks pengguna dirender sebagai teks, bukan HTML', async () => {
    root.querySelector('[data-chat-input]').value = '<img src=x onerror=alert(1)>';
    root.querySelector('[data-chat-form]').dispatchEvent(new Event('submit', { cancelable: true }));
    await tick();
    expect(root.querySelector('[data-chat-log] img')).toBeNull();
  });

  it('membaca aliran SSE dari server saat tersedia', async () => {
    const enc = new TextEncoder();
    const frames = [
      'event: sources\ndata: [{"judul":"Uji","terverifikasi":true,"sumber":[{"label":"Sumber uji"}]}]\n\n',
      'event: delta\ndata: {"t":"Halo "}\n\n',
      'event: delta\ndata: {"t":"dunia"}\n\n',
      'event: done\ndata: {}\n\n',
    ];
    fetch.mockImplementation(async () => ({
      ok: true,
      headers: new Headers({ 'content-type': 'text/event-stream' }),
      body: new ReadableStream({
        start(c) {
          frames.forEach((f) => c.enqueue(enc.encode(f)));
          c.close();
        },
      }),
    }));
    root.querySelector('[data-chat-example="Apa itu batik Kaganga?"]').click();
    await tick();
    expect(root.querySelector('[data-chat-log]').textContent).toContain('Halo dunia');
    expect(root.querySelector('[data-chat-badge]').hidden).toBe(true);
  });
});

describe('kuis', () => {
  let root;
  beforeEach(() => {
    localStorage.clear();
    document.body.innerHTML = readFileSync('src/partials/quiz.html', 'utf8');
    root = document.querySelector('[data-quiz]');
    mountQuiz(root);
  });

  it('menampilkan soal pilihan ganda dengan 4 opsi', () => {
    expect(root.querySelectorAll('[data-option]')).toHaveLength(4);
  });

  it('menjawab memberi umpan balik, memperbarui skor, dan menyimpan progres', () => {
    root.querySelector('[data-option]').click();
    expect(root.querySelector('[data-q="feedback"]').textContent).toMatch(/Benar|Belum tepat/);
    expect(root.querySelector('[data-q="score"]').textContent).toMatch(/^[01] \/ 1$/);
    expect(JSON.parse(localStorage.getItem('diaga-quiz')).total).toBe(1);
    expect(root.querySelector('[data-q="next"]').hidden).toBe(false);
  });

  it('tetap jalan saat localStorage tidak bisa dipakai', () => {
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
      throw new Error('penuh');
    });
    expect(() => root.querySelector('[data-option]').click()).not.toThrow();
  });

  it('mode ketik menampilkan formulir dan menyembunyikan pilihan', () => {
    const select = root.querySelector('[data-q="mode"]');
    select.value = 'aksara-ke-kata';
    select.dispatchEvent(new Event('change'));
    expect(root.querySelector('[data-q="type-form"]').hidden).toBe(false);
    expect(root.querySelector('[data-q="options"]').hidden).toBe(true);
  });
});
