import { describe, it, expect } from 'vitest';
import knowledge from '../src/data/knowledge.json';
import { buildIndex, search, answerOffline, NO_DATA_MESSAGE } from '../src/modules/retrieval.js';

const index = buildIndex(knowledge);
const topId = (q) => search(index, q, 1)[0]?.entry.id;

describe('pencarian pengetahuan', () => {
  it('menemukan alamat perajin', () => {
    expect(topId('di mana alamat Arumbatik Roemah?')).toBe('arumbatik-roemah');
  });
  it('menemukan misi batik', () => {
    expect(topId('apa saja misi batik kaganga')).toBe('misi-batik-kaganga');
  });
  it('menemukan info Unicode', () => {
    expect(topId('blok unicode aksara rejang')).toBe('unicode-rejang');
  });
  it('tidak mengarang untuk pertanyaan di luar topik', () => {
    expect(search(index, 'siapa presiden amerika serikat')).toEqual([]);
    expect(answerOffline(index, 'resep rendang enak').text).toBe(NO_DATA_MESSAGE);
  });
  it('satu kata yang kebetulan cocok tidak cukup (regresi: "dunia")', () => {
    expect(search(index, 'siapa pemenang piala dunia 2010')).toEqual([]);
    expect(answerOffline(index, 'siapa pemenang piala dunia').text).toBe(NO_DATA_MESSAGE);
  });
  it('pertanyaan alami tetap ketemu', () => {
    expect(topId('Kenapa batik tulis makin sulit ditemukan?')).toBe('kondisi-batik-kini');
    expect(topId('siapa yang membuat batik kaganga')).toBeTruthy();
  });
  it('jawaban offline menyertakan penanda sumber', () => {
    const r = answerOffline(index, 'apa itu batik besurek');
    expect(r.text).toContain('[1]');
    expect(r.sources.length).toBeGreaterThan(0);
  });
  it('semua entri tanpa sumber ditandai belum terverifikasi', () => {
    for (const e of knowledge) if (!e.sumber.length) expect(e.terverifikasi).toBe(false);
  });
});
