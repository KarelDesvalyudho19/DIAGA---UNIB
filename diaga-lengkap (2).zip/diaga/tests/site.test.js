// @vitest-environment node
// Membangun situs ke folder sementara lalu memeriksa struktur setiap halaman.
import { describe, it, expect, beforeAll } from 'vitest';
import { build } from 'vite';
import { JSDOM } from 'jsdom';
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const out = resolve('node_modules/.tmp-site');
const pages = {};
const EXTERNAL_OK = [
  'https://curupkami.blogspot.com/',
  'https://www.google.com/maps/',
  'https://keepachangelog.com/',
];

beforeAll(async () => {
  await build({ logLevel: 'silent', build: { outDir: out, emptyOutDir: true } });
  for (const f of readdirSync(out).filter((n) => n.endsWith('.html'))) {
    pages[f] = new JSDOM(readFileSync(resolve(out, f), 'utf8')).window.document;
  }
}, 60000);

const real = () => Object.entries(pages).filter(([f]) => f !== '404.html');

describe('struktur halaman', () => {
  it('membangun 7 halaman', () => {
    expect(Object.keys(pages).sort()).toEqual([
      '404.html',
      'batik.html',
      'belajar.html',
      'index.html',
      'pemandu-ai.html',
      'sentra-kreatif.html',
      'tentang.html',
    ]);
  });

  it.each(['index', 'belajar', 'pemandu-ai', 'batik', 'sentra-kreatif', 'tentang', '404'])(
    '%s: landmark, judul, dan meta dasar lengkap',
    (name) => {
      const d = pages[`${name}.html`];
      expect(d.documentElement.lang).toBe('id');
      expect(d.title.length).toBeGreaterThan(5);
      expect(d.querySelector('meta[name="description"]')?.content.length).toBeGreaterThan(20);
      expect(d.querySelectorAll('h1')).toHaveLength(1);
      expect(d.querySelectorAll('main#isi')).toHaveLength(1);
      expect(d.querySelector('header nav[aria-label]')).not.toBeNull();
      expect(d.querySelector('footer')).not.toBeNull();
      expect(d.querySelector('a.skip-link[href="#isi"]')).not.toBeNull();
      expect(d.querySelector('meta[name="viewport"]')).not.toBeNull();
    },
  );

  it('tidak ada tag placeholder partial yang tersisa', () => {
    for (const [f, d] of Object.entries(pages))
      expect(d.documentElement.innerHTML, f).not.toContain('<!--@');
  });

  it('urutan heading tidak melompat lebih dari satu tingkat', () => {
    for (const [f, d] of real()) {
      let prev = 1;
      for (const h of d.querySelectorAll('main h1, main h2, main h3, main h4')) {
        const level = Number(h.tagName[1]);
        expect(level - prev, `${f}: ${h.textContent.trim()}`).toBeLessThanOrEqual(1);
        prev = level;
      }
    }
  });
});

describe('tautan dan aset', () => {
  it('semua tautan internal dan anchor-nya ada', () => {
    for (const [f, d] of Object.entries(pages)) {
      for (const a of d.querySelectorAll('a[href]')) {
        const href = a.getAttribute('href');
        if (/^https?:/.test(href)) continue;
        const [path, hash] = href.split('#');
        const file = path === '' ? f : path === '/' ? 'index.html' : path.replace(/^\//, '');
        expect(existsSync(resolve(out, file)), `${f} -> ${href}`).toBe(true);
        if (hash) {
          const target =
            pages[file] ?? new JSDOM(readFileSync(resolve(out, file), 'utf8')).window.document;
          expect(target.getElementById(hash), `${f} -> ${href}`).not.toBeNull();
        }
      }
    }
  });

  it('tautan luar hanya ke sumber yang dikenal dan memakai rel noopener', () => {
    for (const [f, d] of Object.entries(pages)) {
      for (const a of d.querySelectorAll('a[href^="http"]')) {
        expect(
          EXTERNAL_OK.some((p) => a.href.startsWith(p)),
          `${f}: ${a.href}`,
        ).toBe(true);
        expect(a.rel, `${f}: ${a.href}`).toContain('noopener');
      }
    }
  });

  it('gambar punya alt, width, dan height (menghindari CLS)', () => {
    for (const [f, d] of Object.entries(pages)) {
      for (const img of d.querySelectorAll('img')) {
        expect(img.hasAttribute('alt'), f).toBe(true);
        expect(img.getAttribute('width'), f).toBeTruthy();
        expect(img.getAttribute('height'), f).toBeTruthy();
      }
    }
  });

  it('cocok dengan CSP: tanpa skrip inline dan tanpa aset pihak ketiga', () => {
    for (const [f, d] of Object.entries(pages)) {
      for (const s of d.querySelectorAll('script')) {
        expect(s.getAttribute('src'), `${f}: skrip inline`).toBeTruthy();
        expect(s.src.startsWith('http'), f).toBe(false);
      }
      expect(d.querySelectorAll('[onclick],[onload],[onerror]').length, f).toBe(0);
      for (const l of d.querySelectorAll('link[href]'))
        expect(l.href.startsWith('http'), f).toBe(false);
    }
  });

  it('semua file font dan gambar yang dirujuk ada', () => {
    const css = readdirSync(resolve(out, 'assets')).find((n) => n.endsWith('.css'));
    const text = readFileSync(resolve(out, 'assets', css), 'utf8');
    expect(text).toContain('Noto Sans Rejang');
    expect(text).toContain('U+A930-A95F');
    expect(existsSync(resolve(out, 'fonts/noto-sans-rejang-rejang-400-normal.woff2'))).toBe(true);
    for (const img of pages['batik.html'].querySelectorAll('img')) {
      if (img.getAttribute('src').startsWith('data:')) continue;
      expect(existsSync(resolve(out, img.getAttribute('src').slice(1)))).toBe(true);
    }
  });
});

describe('isi khusus', () => {
  it('konverter statis sudah memuat aksara "Bengkulu" tanpa JS', () => {
    const out1 = pages['belajar.html'].querySelector('[data-conv-output]');
    expect(out1.textContent).toBe('\uA937\uA949\uA94F\uA930\uA948\uA93E\uA948');
  });
  it('galeri merender 23 ubin huruf', () => {
    expect(pages['belajar.html'].querySelectorAll('[data-letter]')).toHaveLength(23);
  });
  it('koleksi 8 foto, songket bukan kategori Batik', () => {
    const d = pages['batik.html'];
    expect(d.querySelectorAll('[data-photo]')).toHaveLength(8);
    expect(d.body.textContent).toContain('Tekstil Bengkulu');
  });
  it('halaman Tentang memuat changelog dan diagram berjudul', () => {
    const d = pages['tentang.html'];
    expect(d.querySelector('#changelog h3')).not.toBeNull();
    expect(d.querySelector('svg title')?.textContent).toContain('arsitektur');
  });
  it('tidak memuat klaim yang dilarang', () => {
    for (const [f, d] of Object.entries(pages)) {
      expect(d.body.textContent, f).not.toMatch(
        /gratis dan tanpa batas|di era digital ini|tak lekang oleh waktu/i,
      );
    }
  });
  it('navigasi menandai halaman aktif', () => {
    for (const [f, d] of real())
      expect(d.querySelectorAll('nav [aria-current="page"]'), f).toHaveLength(1);
  });
});
