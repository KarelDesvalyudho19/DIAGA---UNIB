// @vitest-environment jsdom
import { describe, it, expect, beforeEach } from 'vitest';
import { readFileSync } from 'node:fs';
import { mountConverter } from '../src/modules/converter-ui.js';

describe('UI konverter', () => {
  let root;
  beforeEach(() => {
    document.body.innerHTML = readFileSync('src/partials/converter.html', 'utf8');
    root = document.querySelector('[data-converter]');
    mountConverter(root);
  });

  it('menampilkan aksara dan rincian suku kata untuk nilai awal', () => {
    expect(root.querySelector('[data-conv-output]').textContent).toBe(
      '\uA937\uA949\uA94F\uA930\uA948\uA93E\uA948',
    );
    expect(root.querySelectorAll('[data-conv-breakdown] li')).toHaveLength(3);
  });

  it('memperbarui hasil saat contoh cepat diklik', () => {
    root.querySelector('[data-example="Rafflesia"]').click();
    const notice = root.querySelector('[data-conv-notice]').textContent;
    expect(notice).toContain('f');
    expect(root.querySelector('[data-conv-breakdown] .unmapped')).not.toBeNull();
  });

  it('opsi pengganti menghilangkan peringatan', () => {
    root.querySelector('[data-example="Rafflesia"]').click();
    const box = root.querySelector('[data-conv-sub]');
    box.checked = true;
    box.dispatchEvent(new Event('change'));
    expect(root.querySelector('[data-conv-notice]').textContent).toBe('');
  });
});
