# Yang harus diisi atau dicek manusia

## Wajib sebelum dilombakan

- [ ] Coba di **HP sungguhan, Safari, dan Firefox**. Pengujian sejauh ini hanya di Chrome headless (lihat `e2e/`).
- [ ] Jalankan ulang Lighthouse setelah deploy (`BASE=https://... npm run lighthouse` di `e2e/`); pengukuran saya di server lokal.
- [ ] Isi `AI_PROVIDER`, `AI_API_KEY` di Vercel, lalu coba Pemandu sungguhan. Adapter belum pernah menyentuh API asli. Bila memakai Gemini, `AI_MODEL` wajib diisi dengan nama model yang masih aktif (cek ai.google.dev/gemini-api/docs/models).
- [ ] Isi `SITE_URL` di Vercel agar `sitemap.xml` terbentuk.
- [ ] Ganti identitas git (`git config user.name` dan `user.email`).

## Konten dan sumber

- [ ] Validasi ejaan dengan narasumber Rejang: vokal e (pepet/taleng), vokal berurutan, konsonan akhir. Ubah di `src/data/aksara.json`, lalu ganti catatan validasi di konverter dan halaman Tentang.
- [ ] Contoh kata bahasa Rejang untuk tiap huruf (sengaja kosong, tidak dikarang).
- [ ] Sumber yang lebih kuat untuk sejarah batik Kaganga (satu-satunya sumber: blog 2009). Setelah ada, perbarui `src/data/knowledge.json` dan set `terverifikasi: true`.
- [ ] Verifikasi asal usul aksara ("rumpun Brahmi") dan tambahkan sumbernya di `knowledge.json`.
- [ ] Izin dan testimoni langsung dari Arumbatik Roemah; konfirmasi alamat.
- [ ] Foto asli: taruh di `public/images/`, perbarui `src/data/batik.json` (nama file, alt, keterangan, kredit), kompres ke WebP. Sekarang semuanya gambar pengganti SVG.
- [ ] Data pendukung masalah untuk proposal (`docs/PROPOSAL-NOTES.md`).
- [ ] Nama anggota tim (halaman Tentang).
- [ ] Domain.

## Sengaja belum dibuat

- Adapter Netlify.
- Partikel canvas dan cursor glow (opsional di prompt).
- Penjelasan jawaban salah di kuis oleh AI (sekarang memakai teks dari data).
- Gambar Open Graph dan versi WebP foto (menunggu foto asli).
