# Changelog

Format mengikuti [Keep a Changelog](https://keepachangelog.com/id-ID/1.1.0/).

## [Belum dirilis]

### Ditambahkan

- Paket `e2e/`: pemeriksaan peramban (konsol, request, overflow, 26 fitur) dan Lighthouse yang bisa diulang.
- Fase 5: mode demo (`?demo=1`), parallax hero yang menghormati `prefers-reduced-motion`, `vercel.json` dengan CSP dan header keamanan, sitemap otomatis bila `SITE_URL` diisi, dokumen `docs/`, halaman Tentang yang merender changelog ini.
- Fase 4: generator "Tulis Namamu di Batik" (canvas, 3 palet, unduh PNG) dan kuis adaptif dengan kotak Leitner, tiga jenis soal, progres di localStorage.
- Fase 3: halaman Batik (sejarah, koleksi dengan lightbox), Sentra Kreatif, dan Tentang (diagram arsitektur, etika, sumber, roadmap).
- Fase 2: Pemandu Kaganga. `knowledge.json`, pencarian BM25, fungsi `api/chat.js` (streaming, batas per IP, adapter Anthropic dan Gemini), UI chat, widget mengambang, mode offline.
- Fase 0: Vite multi-page, Tailwind lewat build, token warna gelap/terang, font dihosting sendiri (Cinzel, Inter, Noto Sans Rejang), header dan footer bersama, transisi halaman (View Transitions), halaman 404.
- Fase 1: parser suku kata Latin ke Rejang yang aturannya ada di `src/data/aksara.json`, konverter dengan rincian per suku kata, galeri 23 huruf dengan panel detail, 32 unit test.

### Diperbaiki

- Model bawaan Gemini (`gemini-2.5-flash`) sudah usang: aksesnya dibatasi dan dijadwalkan dimatikan Oktober 2026. Bawaan dihapus; `AI_MODEL` wajib diisi untuk Gemini, dengan pesan error yang bersih bila kosong.

- Header di layar 360px pecah jadi dua baris dan menutupi judul saat lompat ke anchor. Sekarang satu baris (label tema dipersingkat).
- Aksara besar di hero bergeser saat font dimuat (CLS 0,114). Font Rejang di-preload dan lebar elemen dikunci; CLS kini 0,01.
- Hasil konverter muncul seketika saat mengetik; sebelumnya ada jeda 200 ms.
- Audit aksesibilitas `label-content-name-mismatch`: `aria-label` pada logo, ubin galeri, dan tombol foto dihapus/diselaraskan dengan teks yang terlihat. Ubin galeri kini berlabel bunyi lengkap ("ka", "nga").
- Pencarian menjawab pertanyaan di luar topik dengan data yang tidak nyambung hanya karena satu kata kebetulan cocok. Sekarang butuh cakupan kata kunci minimal 40%.
- Kontras tombol utama di tema terang naik dari 4,45 ke di atas 4,5 (WCAG AA).
- `<img>` di lightbox tidak lagi tanpa `src`.

## [0.1.0] - Rebuild dari versi tugas

Versi awal yang dibangun ulang dari situs tugas kuliah. Konverter lama hanya memetakan suku kata dasar, sehingga kata nyata seperti "bengkulu" tidak berubah.
