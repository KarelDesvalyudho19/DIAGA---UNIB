# DIAGA: Digitalisasi Aksara Kaganga

Museum digital untuk belajar aksara Kaganga (Rejang, Bengkulu), melihatnya di batik, dan terhubung ke perajin. Dibuat untuk lomba Web Development RAFATECH 2026, tema APEX.

Alurnya: belajar aksara, tulis namamu di batik, kenali perajinnya. Pemandu AI menemani di sepanjang jalan.

## Fitur

- **Konverter** Latin ke Rejang dengan rincian per suku kata dan kode Unicode.
- **Galeri** 23 huruf dengan panel detail.
- **Pemandu Kaganga**: chat AI yang menjawab dari data kurasi, menyebut sumber, dan tetap jalan offline.
- **Kuis adaptif** (kotak Leitner) dengan tiga jenis soal.
- **Tulis namamu di batik**: canvas dengan motif Rafflesia, unduh PNG.
- Sejarah batik, koleksi foto dengan lightbox, profil Arumbatik Roemah, dan halaman Tentang.

## Menjalankan

```bash
npm install
npm run dev      # server lokal (chat memakai mode offline karena /api tidak jalan di sini)
npm run build    # hasil di dist/
npm test         # 88 test: parser, retrieval, API, UI, struktur situs
# uji peramban + Lighthouse: lihat e2e/README.md
npm run lint
```

Untuk mencoba chat dengan AI sungguhan secara lokal: `npx vercel dev` setelah mengisi `.env` dari `.env.example`.

## Deploy ke Vercel

1. Impor repo di Vercel. Framework preset: Vite. Build `npm run build`, output `dist`.
2. Isi environment variable: `AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL` (**wajib untuk Gemini**, opsional untuk Anthropic), `SITE_URL` (opsional, untuk sitemap).
3. Deploy. Header keamanan dan CSP diatur di `vercel.json`.

## Struktur

```
*.html            halaman (header/footer/komponen disisipkan saat build)
api/              fungsi serverless chat
src/data/         aksara.json, knowledge.json, batik.json
src/modules/      converter, retrieval, chat, quiz, batik-generator, gallery, ...
src/partials/     potongan HTML bersama
tests/            Vitest
docs/             KRITERIA, ARSITEKTUR, DEMO, PROPOSAL-NOTES
```

## Catatan penting

- Aturan transliterasi ada di `src/data/aksara.json`. Koreksi narasumber cukup mengubah file itu.
- Kontras teks dihitung untuk kedua tema; semua pasangan teks utama di atas 4,5:1 (WCAG AA).
- Sudah diuji di Chrome headless (7 halaman x 360/1440 px): tanpa error konsol, tanpa request gagal, tanpa overflow horizontal, 26 pemeriksaan fitur lolos. Lighthouse (emulasi mobile, server lokal) di halaman yang diukur: 100 di Performance, Accessibility, Best Practices, dan SEO. Skrip ada di `e2e/`. Belum diuji di Safari, Firefox, atau HP sungguhan, dan skor bisa berbeda setelah deploy.
- Adapter AI belum diuji terhadap API sungguhan. Jalur streaming server ke UI sudah diuji dengan penyedia tiruan (`e2e/stream.mjs`). Nama model Gemini harus Anda isi sendiri dan periksa di dokumentasi Google.
- Ejaan Rejang belum divalidasi penuh oleh narasumber.

Pemetaan fitur ke kriteria juri: `docs/KRITERIA.md`. Skrip demo: `docs/DEMO.md`.
