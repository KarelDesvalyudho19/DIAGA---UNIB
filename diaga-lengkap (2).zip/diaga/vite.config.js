import { defineConfig } from 'vite';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve, basename } from 'node:path';
import aksara from './src/data/aksara.json' with { type: 'json' };
import batik from './src/data/batik.json' with { type: 'json' };
import { changelogToHtml } from './src/build/markdown.js';

const root = import.meta.dirname;

// Halaman HTML di root menjadi entry multi-page (404 ikut dibangun).
const pages = readdirSync(root).filter((f) => f.endsWith('.html'));

// Header dan footer dipakai bersama lewat partial supaya tidak diduplikasi
// di enam halaman. Dirender saat build, jadi tetap terbaca tanpa JavaScript.
// Ubin galeri dirender dari data saat build agar tetap terlihat tanpa JS.
function galleryTiles() {
  return aksara.huruf
    .map(
      (h, i) =>
        `<li><button type="button" class="letter-tile w-full" data-letter="${i}">` +
        `<span class="rejang" lang="rej" aria-hidden="true">${String.fromCodePoint(parseInt(h.kode, 16))}</span>` +
        `<span class="mt-1 text-sm text-muted">${h.id}</span></button></li>`,
    )
    .join('');
}

function koleksiTiles() {
  return batik.foto
    .map(
      (f, i) =>
        `<li><button type="button" class="photo-tile w-full text-left" data-photo="${i}">` +
        `<img src="/images/${f.file}.svg" width="800" height="600" alt="${f.alt}" loading="lazy" class="w-full rounded-lg">` +
        `<span class="mt-2 block font-semibold">${f.judul}</span><span class="block text-sm text-muted">${f.kategori}</span></button></li>`,
    )
    .join('');
}

// Sitemap dibuat hanya kalau alamat situs diketahui (env SITE_URL); URL karangan lebih buruk daripada tanpa sitemap.
function sitemap() {
  return {
    name: 'diaga-sitemap',
    generateBundle() {
      const site = process.env.SITE_URL?.replace(/\/$/, '');
      if (!site) return;
      const urls = pages
        .filter((f) => f !== '404.html')
        .map((f) => (f === 'index.html' ? '/' : `/${f}`));
      const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `  <url><loc>${site}${u}</loc></url>`).join('\n')}\n</urlset>\n`;
      this.emitFile({ type: 'asset', fileName: 'sitemap.xml', source: xml });
    },
  };
}

function partials() {
  const read = (name) => readFileSync(resolve(root, 'src/partials', name), 'utf8');
  return {
    name: 'diaga-partials',
    transformIndexHtml: {
      order: 'pre',
      handler(html, ctx) {
        const current = basename(ctx.filename);
        const header = read('header.html').replace(
          new RegExp(`(href="/${current === 'index.html' ? '' : current}")`),
          '$1 aria-current="page"',
        );
        return html
          .replace('<!--@header-->', header)
          .replace('<!--@footer-->', read('footer.html'))
          .replaceAll('<!--@chat-->', read('chat.html'))
          .replace('<!--@converter-->', read('converter.html'))
          .replace('<!--@converter-mini-->', read('converter-mini.html'))
          .replace('<!--@gallery-detail-->', read('gallery-detail.html'))
          .replace('<!--@gallery-tiles-->', galleryTiles())
          .replace('<!--@koleksi-tiles-->', koleksiTiles())
          .replace('<!--@lightbox-->', read('lightbox.html'))
          .replace('<!--@batik-generator-->', read('batik-generator.html'))
          .replace('<!--@quiz-->', read('quiz.html'))
          .replace(
            '<!--@changelog-->',
            changelogToHtml(readFileSync(resolve(root, 'CHANGELOG.md'), 'utf8')),
          );
      },
    },
  };
}

export default defineConfig({
  plugins: [partials(), sitemap()],
  build: {
    rollupOptions: {
      input: Object.fromEntries(pages.map((f) => [basename(f, '.html'), resolve(root, f)])),
    },
  },
  test: { environment: 'node', include: ['tests/**/*.test.js'] },
});
