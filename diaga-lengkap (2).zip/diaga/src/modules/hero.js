// Parallax halus untuk aksara besar di hero. Mati bila pengguna minta gerak dikurangi.
export function initHero() {
  const glyph = document.querySelector('[data-hero-glyph]');
  if (!glyph || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  let ticking = false;
  window.addEventListener(
    'scroll',
    () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        glyph.style.transform = `translateY(${Math.min(window.scrollY, 600) * 0.15}px)`;
        ticking = false;
      });
    },
    { passive: true },
  );
}
