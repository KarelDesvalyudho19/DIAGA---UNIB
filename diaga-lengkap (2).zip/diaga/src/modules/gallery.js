// Galeri aksara: ubin huruf dirender saat build (lihat vite.config.js),
// modul ini hanya menambahkan panel detail. Memakai <dialog> bawaan
// supaya focus trap dan tombol Escape ditangani peramban.
import data from '../data/aksara.json';

const toChar = (hex) => String.fromCodePoint(parseInt(hex, 16));

export function initGallery() {
  const dialog = document.querySelector('[data-detail]');
  const tiles = document.querySelectorAll('[data-letter]');
  if (!dialog || !tiles.length) return;

  const q = (name) => dialog.querySelector(`[data-d="${name}"]`);
  const speakBtn = q('speak');
  const canSpeak = 'speechSynthesis' in window;
  if (!canSpeak) speakBtn.hidden = true;

  let index = 0;
  let opener = null;

  const show = (i) => {
    index = (i + data.huruf.length) % data.huruf.length;
    const h = data.huruf[index];
    q('glyph').textContent = toChar(h.kode);
    q('latin').textContent = h.id;
    q('code').textContent = `U+${h.kode} · REJANG LETTER ${h.namaUnicode}`;
    q('sound').textContent = h.bunyi;
    q('pos').textContent = `${index + 1} dari ${data.huruf.length}`;
    speakBtn.dataset.say = h.mirip;
  };

  tiles.forEach((tile) => {
    tile.addEventListener('click', () => {
      opener = tile;
      show(Number(tile.dataset.letter));
      dialog.showModal();
    });
  });

  q('prev').addEventListener('click', () => show(index - 1));
  q('next').addEventListener('click', () => show(index + 1));
  q('close').addEventListener('click', () => dialog.close());

  // Klik di area gelap di luar kartu juga menutup.
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) dialog.close();
  });
  dialog.addEventListener('close', () => opener?.focus());
  dialog.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') show(index - 1);
    if (e.key === 'ArrowRight') show(index + 1);
  });

  // Ini pendekatan pengucapan lewat suara Indonesia, bukan rekaman penutur Rejang.
  speakBtn.addEventListener('click', () => {
    if (!canSpeak) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(speakBtn.dataset.say);
    u.lang = 'id-ID';
    u.rate = 0.8;
    window.speechSynthesis.speak(u);
  });
}
