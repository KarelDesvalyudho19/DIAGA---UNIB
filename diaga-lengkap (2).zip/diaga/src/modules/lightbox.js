// Lightbox koleksi foto. Memakai <dialog> agar fokus terkunci dan Escape berfungsi.
import data from '../data/batik.json';

export function initLightbox() {
  const dialog = document.querySelector('[data-lightbox]');
  const tiles = document.querySelectorAll('[data-photo]');
  if (!dialog || !tiles.length) return;

  const q = (n) => dialog.querySelector(`[data-l="${n}"]`);
  const fotos = data.foto;
  let index = 0;
  let opener = null;

  const show = (i) => {
    index = (i + fotos.length) % fotos.length;
    const f = fotos[index];
    const img = q('img');
    img.src = `/images/${f.file}.svg`;
    img.alt = f.alt;
    q('title').textContent = f.judul;
    q('caption').textContent = `${f.keterangan} ${f.kredit}.`;
    q('cat').textContent = f.kategori;
    q('pos').textContent = `${index + 1} dari ${fotos.length}`;
  };

  tiles.forEach((t) =>
    t.addEventListener('click', () => {
      opener = t;
      show(Number(t.dataset.photo));
      dialog.showModal();
    }),
  );
  q('prev').addEventListener('click', () => show(index - 1));
  q('next').addEventListener('click', () => show(index + 1));
  q('close').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) dialog.close();
  });
  dialog.addEventListener('close', () => opener?.focus());
  dialog.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') show(index - 1);
    if (e.key === 'ArrowRight') show(index + 1);
  });
}
