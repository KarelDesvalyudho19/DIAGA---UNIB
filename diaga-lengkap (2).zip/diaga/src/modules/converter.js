// Parser transliterasi Latin -> aksara Rejang (Kaganga).
// Semua aturan dibaca dari src/data/aksara.json supaya bisa dikoreksi
// tanpa menyentuh logika (ejaan Rejang masih perlu validasi narasumber).

import defaultData from '../data/aksara.json';

const toChar = (hex) => String.fromCodePoint(parseInt(hex, 16));
const byLengthDesc = (a, b) => b.length - a.length;

/** Menyiapkan tabel pencarian dari data mentah. */
export function buildRules(data = defaultData) {
  const letterCode = Object.fromEntries(data.huruf.map((h) => [h.id, h.kode]));
  // Konsonan tunggal: huruf dasar yang onset-nya satu karakter.
  const singles = {};
  for (const h of data.huruf) {
    if (h.kelompok === 'dasar' && h.onset.length === 1) singles[h.onset] = h.kode;
  }
  return {
    data,
    letterCode,
    singles,
    onsetCode: Object.fromEntries(
      Object.entries(data.onsetGanda).map(([lat, id]) => [lat, letterCode[id]]),
    ),
    onsetKeys: Object.keys(data.onsetGanda).sort(byLengthDesc),
    vowelKeys: Object.keys(data.tandaVokal).concat(data.vokalInheren).sort(byLengthDesc),
  };
}

const defaultRules = buildRules();

function vowelAt(word, pos, rules) {
  for (const v of rules.vowelKeys) if (word.startsWith(v, pos)) return v;
  return null;
}

// Memecah satu kata menjadi token V (vokal), C (konsonan/onset), U (belum ada padanan).
function tokenize(word, rules) {
  const tokens = [];
  let i = 0;
  while (i < word.length) {
    const v = vowelAt(word, i, rules);
    if (v) {
      tokens.push({ t: 'V', s: v });
      i += v.length;
      continue;
    }
    let matched = null;
    for (const key of rules.onsetKeys) {
      if (!word.startsWith(key, i)) continue;
      // "ng" boleh berdiri sendiri (konsonan akhir). Onset ganda lain
      // hanya sah kalau langsung diikuti vokal, kalau tidak dipecah.
      const needsVowel = rules.data.onsetBerikutVokal.includes(key);
      if (!needsVowel || vowelAt(word, i + key.length, rules)) {
        matched = key;
        break;
      }
    }
    if (matched) {
      tokens.push({ t: 'C', s: matched, code: rules.onsetCode[matched] });
      i += matched.length;
      continue;
    }
    const ch = word[i];
    if (rules.singles[ch]) tokens.push({ t: 'C', s: ch, code: rules.singles[ch] });
    else tokens.push({ t: 'U', s: ch });
    i += 1;
  }
  return tokens;
}

function makeSyllable(latin, codes) {
  return { latin, codes, glyph: codes.map(toChar).join(''), unmapped: false };
}

// Menyusun token menjadi suku kata: onset + vokal + (opsional) konsonan akhir.
function syllabify(tokens, rules) {
  const { data } = rules;
  const out = [];
  let i = 0;
  const isV = (tk) => tk && tk.t === 'V';

  while (i < tokens.length) {
    const tk = tokens[i];

    if (tk.t === 'U') {
      out.push({ latin: tk.s, codes: [], glyph: tk.s, unmapped: true });
      i += 1;
      continue;
    }

    let latin;
    const codes = [];

    if (tk.t === 'V') {
      // Kata atau suku kata berawal vokal memakai huruf A.
      codes.push(data.vokalAwal);
      if (tk.s !== data.vokalInheren) codes.push(data.tandaVokal[tk.s]);
      latin = tk.s;
      i += 1;
    } else if (isV(tokens[i + 1])) {
      const v = tokens[i + 1];
      codes.push(tk.code);
      if (v.s !== data.vokalInheren) codes.push(data.tandaVokal[v.s]);
      latin = tk.s + v.s;
      i += 2;
    } else {
      // Konsonan tanpa vokal (gugus konsonan): huruf + virama.
      out.push(makeSyllable(tk.s, [tk.code, data.virama]));
      i += 1;
      continue;
    }

    // Konsonan akhir: konsonan yang tidak diikuti vokal.
    const coda = tokens[i];
    if (coda && coda.t === 'C' && !isV(tokens[i + 1])) {
      const sign = data.tandaAkhir[coda.s];
      if (sign) codes.push(sign);
      else codes.push(coda.code, data.virama);
      latin += coda.s;
      i += 1;
    }

    out.push(makeSyllable(latin, codes));
  }
  return out;
}

function applySubstitution(word, rules) {
  return [...word].map((ch) => rules.data.pengganti[ch] ?? ch).join('');
}

/** Mengubah satu kata Latin menjadi daftar suku kata Rejang. */
export function convertWord(word, { substitute = false, rules = defaultRules } = {}) {
  let w = word
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
  if (substitute) w = applySubstitution(w, rules);
  return syllabify(tokenize(w, rules), rules);
}

/**
 * Mengubah teks penuh. Hasil berupa potongan (kata dan pemisah)
 * supaya UI bisa menampilkan rincian per suku kata.
 */
export function convertText(text, options = {}) {
  const segments = [];
  let glyph = '';
  let hasUnmapped = false;
  for (const part of text.split(/(\p{L}+)/u)) {
    if (!part) continue;
    if (/^\p{L}+$/u.test(part)) {
      const syllables = convertWord(part, options);
      if (syllables.some((s) => s.unmapped)) hasUnmapped = true;
      glyph += syllables.map((s) => s.glyph).join('');
      segments.push({ type: 'word', latin: part, syllables });
    } else {
      glyph += part;
      segments.push({ type: 'sep', text: part });
    }
  }
  return { segments, glyph, hasUnmapped };
}

/** Kode heksadesimal per karakter, mis. "A930 A947". */
export const codesOf = (syllable) => syllable.codes.join(' ');
