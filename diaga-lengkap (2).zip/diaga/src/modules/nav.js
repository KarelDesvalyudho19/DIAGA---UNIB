// Menu mobile: buka/tutup, tutup dengan Escape, dan tutup saat pindah ke layar lebar.
export function initNav() {
  const button = document.querySelector('[data-menu-toggle]');
  const list = document.getElementById('nav-list');
  if (!button || !list) return;

  const setOpen = (open) => {
    list.dataset.open = String(open);
    button.setAttribute('aria-expanded', String(open));
    button.textContent = open ? 'Tutup' : 'Menu';
  };

  button.addEventListener('click', () => setOpen(list.dataset.open !== 'true'));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && list.dataset.open === 'true') {
      setOpen(false);
      button.focus();
    }
  });
  window.matchMedia('(min-width: 768px)').addEventListener('change', (e) => {
    if (e.matches) setOpen(false);
  });
}
