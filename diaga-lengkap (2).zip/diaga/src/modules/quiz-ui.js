// Antarmuka kuis. Progres disimpan di localStorage bila tersedia; kalau tidak, jalan di memori.
import aksara from '../data/aksara.json';
import { MODES, emptyState, makeQuestion, isCorrect, grade, boxOf } from './quiz-logic.js';

const KEY = 'diaga-quiz';
const toChar = (hex) => String.fromCodePoint(parseInt(hex, 16));

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(KEY));
    if (saved && typeof saved === 'object' && saved.items) return { ...emptyState(), ...saved };
  } catch {
    /* tidak ada data tersimpan */
  }
  return emptyState();
}

function save(state) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* mode privat atau storage penuh: lanjut tanpa menyimpan */
  }
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

export function mountQuiz(root) {
  const $ = (n) => root.querySelector(`[data-q="${n}"]`);
  let state = load();
  let mode = 'bunyi-ke-huruf';
  let question = null;
  let answered = false;

  const modeSelect = $('mode');
  for (const [value, label] of Object.entries(MODES)) modeSelect.append(new Option(label, value));

  function renderStats() {
    $('score').textContent = `${state.correct} / ${state.total}`;
    $('streak').textContent = String(state.streak);
    $('best').textContent = String(state.best);
  }

  function renderProgress() {
    const grid = $('progress');
    grid.replaceChildren();
    for (const h of aksara.huruf) {
      const seen = state.items[h.id]?.seen ?? 0;
      const cell = el('li', 'flex flex-col items-center rounded-md border px-1 py-2 text-center');
      cell.style.borderColor = 'rgb(var(--line) / var(--line-alpha))';
      cell.append(
        el('span', 'rejang text-2xl text-gold-ink', toChar(h.kode)),
        el('span', 'text-xs text-muted', seen ? `kotak ${boxOf(state, h.id)}` : 'belum'),
      );
      grid.append(cell);
    }
  }

  function showFeedback(ok) {
    const fb = $('feedback');
    fb.replaceChildren(
      el(
        'p',
        ok ? 'font-semibold text-emerald' : 'font-semibold text-gold-ink',
        ok ? 'Benar.' : 'Belum tepat.',
      ),
      el('p', 'mt-1 text-muted', question.explanation),
    );
    $('next').hidden = false;
    $('next').focus();
  }

  function answer(given) {
    if (answered) return;
    answered = true;
    const ok = isCorrect(question, given);
    state = grade(state, question.itemId, ok);
    save(state);
    root.querySelectorAll('[data-option]').forEach((b) => {
      b.disabled = true;
      if (b.dataset.option === question.answer) b.dataset.state = 'benar';
      else if (b.dataset.option === given) b.dataset.state = 'salah';
    });
    $('type-input').disabled = true;
    showFeedback(ok);
    renderStats();
    renderProgress();
  }

  function next() {
    answered = false;
    question = makeQuestion(mode, state, Math.random, question?.itemId);
    $('prompt').textContent = question.prompt;
    const glyph = $('glyph');
    glyph.textContent = question.glyph ?? '';
    glyph.hidden = !question.glyph;
    $('feedback').replaceChildren();
    $('next').hidden = true;

    const opts = $('options');
    opts.replaceChildren();
    const typing = mode === 'aksara-ke-kata';
    $('type-form').hidden = !typing;
    opts.hidden = typing;
    if (typing) {
      $('type-input').value = '';
      $('type-input').disabled = false;
      $('type-input').focus();
    } else {
      question.options.forEach((o, i) => {
        const b = el('button', 'letter-tile w-full');
        b.type = 'button';
        b.dataset.option = o.value;
        if (mode === 'bunyi-ke-huruf') {
          b.append(el('span', 'rejang', o.glyph));
          b.setAttribute('aria-label', `Pilihan ${String.fromCharCode(65 + i)}`);
        } else {
          b.append(el('span', 'text-2xl font-display', o.label));
        }
        b.addEventListener('click', () => answer(o.value));
        opts.append(b);
      });
    }
  }

  modeSelect.addEventListener('change', () => {
    mode = modeSelect.value;
    question = null;
    next();
  });
  $('type-form').addEventListener('submit', (e) => {
    e.preventDefault();
    if ($('type-input').value.trim()) answer($('type-input').value);
  });
  $('next').addEventListener('click', next);
  $('reset').addEventListener('click', () => {
    state = emptyState();
    save(state);
    renderStats();
    renderProgress();
    question = null;
    next();
  });

  renderStats();
  renderProgress();
  next();
}

export function initQuiz() {
  const root = document.querySelector('[data-quiz]');
  if (root) mountQuiz(root);
}
