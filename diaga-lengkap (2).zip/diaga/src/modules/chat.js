// Chat Pemandu Kaganga. Mencoba /api/chat (streaming); kalau gagal atau kena batas,
// menjawab dari pencarian lokal supaya demo tetap jalan tanpa koneksi ke AI.
import knowledge from '../data/knowledge.json';
import { buildIndex, answerOffline } from './retrieval.js';

const index = buildIndex(knowledge);
const TIMEOUT_MS = 25000;

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// Membaca aliran SSE dari fungsi server: sources, delta, done, error.
async function* readEvents(response) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  for (;;) {
    const { value, done } = await reader.read();
    if (done) return;
    buffer += decoder.decode(value, { stream: true });
    let cut;
    while ((cut = buffer.indexOf('\n\n')) !== -1) {
      const block = buffer.slice(0, cut);
      buffer = buffer.slice(cut + 2);
      const event = /^event: (.+)$/m.exec(block)?.[1];
      const data = /^data: (.+)$/m.exec(block)?.[1];
      if (event && data) yield { event, data: JSON.parse(data) };
    }
  }
}

function renderSources(container, sources) {
  container.replaceChildren();
  if (!sources.length) return;
  const details = el('details', 'mt-3 text-sm');
  details.append(
    el('summary', 'cursor-pointer text-gold-ink', `Dasar jawaban (${sources.length})`),
  );
  const list = el('ol', 'mt-2 space-y-3');
  sources.forEach((s, i) => {
    const item = el('li', 'panel !p-3');
    item.append(el('p', 'font-semibold', `[${i + 1}] ${s.judul}`));
    if (!s.terverifikasi) {
      item.append(
        el('p', 'text-xs text-muted', 'Belum terverifikasi. Sumbernya masih perlu dicek tim.'),
      );
    }
    for (const src of s.sumber ?? []) {
      if (src.url) {
        const a = el('a', 'block text-xs', src.label);
        a.href = src.url;
        if (/^https?:/.test(src.url)) a.rel = 'noopener noreferrer';
        item.append(a);
      } else {
        item.append(el('p', 'text-xs text-muted', src.label));
      }
    }
    list.append(item);
  });
  details.append(list);
  container.append(details);
}

export function mountChat(root) {
  const log = root.querySelector('[data-chat-log]');
  const form = root.querySelector('[data-chat-form]');
  const input = root.querySelector('[data-chat-input]');
  const count = root.querySelector('[data-chat-count]');
  const send = root.querySelector('[data-chat-send]');
  const badge = root.querySelector('[data-chat-badge]');
  const empty = root.querySelector('[data-chat-empty]');
  const history = [];
  let busy = false;

  const scroll = () => (log.scrollTop = log.scrollHeight);

  function addUser(text) {
    empty?.remove();
    const row = el(
      'div',
      'self-end max-w-[85%] rounded-2xl rounded-br-sm bg-gold-ink px-4 py-2 text-bg',
    );
    row.textContent = text;
    log.append(row);
    scroll();
  }

  function addAssistant() {
    const wrap = el('div', 'self-start max-w-[92%]');
    const bubble = el('div', 'panel !p-4 whitespace-pre-wrap');
    const typing = el('span', 'text-muted', 'Pemandu sedang menulis…');
    bubble.append(typing);
    const sources = el('div');
    const tools = el('div', 'mt-2 flex gap-2');
    wrap.append(bubble, sources, tools);
    log.append(wrap);
    scroll();
    return { bubble, sources, tools };
  }

  function addCopy(tools, getText) {
    const btn = el('button', 'chip !min-h-[36px] text-xs', 'Salin jawaban');
    btn.type = 'button';
    btn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(getText());
        btn.textContent = 'Tersalin';
      } catch {
        btn.textContent = 'Gagal menyalin';
      }
      setTimeout(() => (btn.textContent = 'Salin jawaban'), 1600);
    });
    tools.append(btn);
  }

  async function askOnline(text, target) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history: history.slice(-6) }),
        signal: ctrl.signal,
      });
      if (!res.ok || !res.headers.get('content-type')?.includes('text/event-stream')) {
        throw new Error('bukan aliran AI');
      }
      let answer = '';
      let sources = [];
      for await (const { event, data } of readEvents(res)) {
        if (event === 'sources') sources = data;
        if (event === 'delta') {
          answer += data.t;
          target.bubble.textContent = answer;
          scroll();
        }
        if (event === 'error') throw new Error(data.error);
      }
      if (!answer) throw new Error('jawaban kosong');
      renderSources(target.sources, sources);
      return answer;
    } finally {
      clearTimeout(timer);
    }
  }

  async function ask(text) {
    if (busy || !text.trim()) return;
    busy = true;
    send.disabled = true;
    addUser(text);
    const target = addAssistant();
    let answer;
    try {
      answer = await askOnline(text, target);
      if (badge) badge.hidden = true;
    } catch {
      const local = answerOffline(index, text);
      answer = local.text;
      target.bubble.textContent = answer;
      renderSources(target.sources, local.sources);
      if (badge) badge.hidden = false;
    }
    addCopy(target.tools, () => answer);
    history.push({ role: 'user', content: text }, { role: 'assistant', content: answer });
    busy = false;
    send.disabled = false;
    scroll();
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = input.value.trim();
    input.value = '';
    count.textContent = '0 / 500';
    ask(text);
  });
  input.addEventListener('input', () => (count.textContent = `${input.value.length} / 500`));
  // Enter mengirim, Shift+Enter baris baru.
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      form.requestSubmit();
    }
  });
  root
    .querySelectorAll('[data-chat-example]')
    .forEach((btn) => btn.addEventListener('click', () => ask(btn.dataset.chatExample)));
  root.querySelector('[data-chat-reset]').addEventListener('click', () => {
    history.length = 0;
    log.replaceChildren(empty ?? el('p', 'text-muted', 'Percakapan dimulai ulang.'));
    if (badge) badge.hidden = true;
    input.focus();
  });

  return { input };
}

// Widget mengambang di halaman selain Pemandu. Tanpa JS, tautannya tetap membuka halaman Pemandu.
export function initChatWidget() {
  const holder = document.querySelector('[data-chat-widget]');
  const template = document.getElementById('chat-template');
  if (!holder || !template || document.querySelector('[data-chat-page]')) return;

  const link = holder.querySelector('a');
  const panel = el('div', 'chat-widget-panel');
  panel.hidden = true;
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', 'Pemandu Kaganga');
  const close = el('button', 'chip ml-auto', 'Tutup');
  close.type = 'button';
  panel.append(close);
  holder.append(panel);
  let mounted = null;

  link.addEventListener('click', (e) => {
    e.preventDefault();
    if (!mounted) {
      panel.append(template.content.cloneNode(true));
      mounted = mountChat(panel.querySelector('[data-chat]'));
    }
    panel.hidden = !panel.hidden;
    link.setAttribute('aria-expanded', String(!panel.hidden));
    if (!panel.hidden) mounted.input.focus();
  });
  close.addEventListener('click', () => {
    panel.hidden = true;
    link.setAttribute('aria-expanded', 'false');
    link.focus();
  });
  panel.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close.click();
  });
}

export function initChatPage() {
  const root = document.querySelector('[data-chat-page] [data-chat]');
  if (!root) return;
  const { input } = mountChat(root);
  if (new URLSearchParams(location.search).get('demo') === '1') {
    input.value = 'Apa itu batik Kaganga?';
    input.dispatchEvent(new Event('input'));
  }
}
