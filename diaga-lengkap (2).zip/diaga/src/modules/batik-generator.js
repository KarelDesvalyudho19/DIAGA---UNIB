// Generator "Tulis Namamu di Batik": motif Rafflesia digambar di canvas
// (bentuknya buatan sendiri), lalu nama dalam aksara Rejang diletakkan di tengah.
import { convertText } from './converter.js';

const SIZE = 1200;

export const PALETTES = {
  sogan: { label: 'Sogan', bg: '#3a2412', motif: '#c9973a', accent: '#7a4a22', ink: '#f3e2b3' },
  nila: { label: 'Nila', bg: '#101c36', motif: '#d4a843', accent: '#24406e', ink: '#f6ecd0' },
  rafflesia: {
    label: 'Rafflesia',
    bg: '#4a1016',
    motif: '#e0b04a',
    accent: '#7d1d26',
    ink: '#fbeecb',
  },
};

function drawRafflesia(ctx, x, y, r, p) {
  ctx.save();
  ctx.translate(x, y);
  for (let k = 0; k < 5; k++) {
    ctx.save();
    ctx.rotate((k * Math.PI * 2) / 5);
    ctx.beginPath();
    ctx.ellipse(0, -r * 0.62, r * 0.4, r * 0.52, 0, 0, Math.PI * 2);
    ctx.fillStyle = p.motif;
    ctx.globalAlpha = 0.85;
    ctx.fill();
    ctx.globalAlpha = 1;
    // bintik khas kelopak Rafflesia
    ctx.fillStyle = p.accent;
    for (const [dx, dy] of [
      [0, -0.85],
      [-0.16, -0.62],
      [0.16, -0.62],
      [0, -0.45],
    ]) {
      ctx.beginPath();
      ctx.arc(dx * r, dy * r, r * 0.05, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.3, 0, Math.PI * 2);
  ctx.fillStyle = p.accent;
  ctx.fill();
  ctx.lineWidth = 4;
  ctx.strokeStyle = p.motif;
  ctx.stroke();
  ctx.restore();
}

function drawDiamond(ctx, x, y, r, p) {
  ctx.beginPath();
  ctx.moveTo(x, y - r);
  ctx.lineTo(x + r, y);
  ctx.lineTo(x, y + r);
  ctx.lineTo(x - r, y);
  ctx.closePath();
  ctx.fillStyle = p.motif;
  ctx.globalAlpha = 0.6;
  ctx.fill();
  ctx.globalAlpha = 1;
}

function fitFont(ctx, text, family, maxWidth, start, min) {
  let size = start;
  for (; size > min; size -= 4) {
    ctx.font = `${size}px ${family}`;
    if (ctx.measureText(text).width <= maxWidth) break;
  }
  return size;
}

export function drawBatik(canvas, { name, glyph, palette }) {
  const ctx = canvas.getContext('2d');
  const p = PALETTES[palette] ?? PALETTES.sogan;
  canvas.width = SIZE;
  canvas.height = SIZE;

  ctx.fillStyle = p.bg;
  ctx.fillRect(0, 0, SIZE, SIZE);

  // Pola: Rafflesia berselang-seling dengan berlian kecil.
  const step = 300;
  for (let row = -1; row <= 4; row++) {
    for (let col = -1; col <= 4; col++) {
      const x = col * step + (row % 2 ? step / 2 : 0) + 150;
      const y = row * (step * 0.8) + 150;
      drawRafflesia(ctx, x, y, 92, p);
      drawDiamond(ctx, x + step / 2, y, 18, p);
      drawDiamond(ctx, x + step / 4, y + step * 0.4, 12, p);
    }
  }

  // Bingkai ganda
  ctx.strokeStyle = p.motif;
  ctx.lineWidth = 10;
  ctx.strokeRect(30, 30, SIZE - 60, SIZE - 60);
  ctx.lineWidth = 3;
  ctx.strokeRect(52, 52, SIZE - 104, SIZE - 104);

  // Panel nama di tengah
  const w = SIZE * 0.84;
  const h = 300;
  const x0 = (SIZE - w) / 2;
  const y0 = (SIZE - h) / 2;
  ctx.fillStyle = p.bg;
  ctx.globalAlpha = 0.94;
  ctx.fillRect(x0, y0, w, h);
  ctx.globalAlpha = 1;
  ctx.strokeStyle = p.motif;
  ctx.lineWidth = 6;
  ctx.strokeRect(x0, y0, w, h);
  ctx.lineWidth = 2;
  ctx.strokeRect(x0 + 14, y0 + 14, w - 28, h - 28);

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = p.ink;
  const rejang = '"Noto Sans Rejang", "Noto Sans", sans-serif';
  const size = fitFont(ctx, glyph, rejang, w - 100, 150, 48);
  ctx.font = `${size}px ${rejang}`;
  ctx.fillText(glyph, SIZE / 2, y0 + h * 0.42);

  ctx.globalAlpha = 0.85;
  const latinFont = 'Inter, system-ui, sans-serif';
  const ls = fitFont(ctx, name, latinFont, w - 100, 40, 20);
  ctx.font = `${ls}px ${latinFont}`;
  ctx.fillText(name, SIZE / 2, y0 + h * 0.82);
  ctx.globalAlpha = 1;
}

const slug = (s) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || 'batik';

export function mountBatik(root) {
  const canvas = root.querySelector('[data-batik-canvas]');
  const input = root.querySelector('[data-batik-name]');
  const download = root.querySelector('[data-batik-download]');
  const notice = root.querySelector('[data-batik-notice]');
  const sub = root.querySelector('[data-batik-sub]');
  if (!canvas || !input) return;

  const palette = () => root.querySelector('[name="palet"]:checked')?.value ?? 'sogan';

  const render = () => {
    const name = input.value.trim() || 'Bengkulu';
    const r = convertText(name, { substitute: Boolean(sub?.checked) });
    drawBatik(canvas, { name, glyph: r.glyph, palette: palette() });
    canvas.setAttribute(
      'aria-label',
      `Kain batik bermotif Rafflesia dengan nama ${name} dalam aksara Rejang`,
    );
    if (notice) {
      notice.textContent = r.hasUnmapped
        ? 'Ada huruf yang belum punya padanan Rejang, jadi tampil apa adanya di kain. Centang opsi ganti huruf untuk memakai padanan terdekat.'
        : '';
    }
  };

  input.addEventListener('input', render);
  sub?.addEventListener('change', render);
  root.querySelectorAll('[name="palet"]').forEach((r) => r.addEventListener('change', render));

  download?.addEventListener('click', () => {
    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `diaga-batik-${slug(input.value)}.png`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    }, 'image/png');
  });

  render();
  // Gambar ulang begitu font aksara siap, supaya tidak tertinggal kotak kosong.
  document.fonts?.load('100px "Noto Sans Rejang"', '\uA930').then(render, () => {});
  document.fonts?.load('40px Inter').then(render, () => {});
}

export function initBatik() {
  const root = document.querySelector('[data-batik]');
  if (root) mountBatik(root);
}
