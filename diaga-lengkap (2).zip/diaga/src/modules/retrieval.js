// Pencarian sederhana (BM25) di knowledge.json. Dipakai dua tempat:
// server (api/chat.js) untuk konteks prompt, dan klien untuk mode offline.

const STOPWORDS = new Set(
  `a ada adalah agar akan aku anda apa atau bagaimana bagi bahwa banyak beberapa belum bisa buat dan dari dapat dengan di dia dong dua ini itu jadi jika juga kah kalau kami kamu karena ke kita lah lagi lain mau mereka nya oleh pada para pun saja saya sebuah sedang sudah tapi tentang untuk yang yg dong deh sih tolong mohon jelaskan ceritakan siapa kenapa mengapa mana kapan berapa bagaimana`.split(
    /\s+/,
  ),
);

const PREFIXES = ['meng', 'mem', 'men', 'ber', 'ter', 'per', 'me', 'di', 'pe', 'se'];
const SUFFIXES = ['nya', 'lah', 'kah', 'kan', 'an', 'i'];

// Stemming ringan, cukup agar "membatik" dan "batik" bertemu. Tidak sempurna, dan tidak perlu.
function stem(word) {
  let w = word;
  for (const s of SUFFIXES) {
    if (w.endsWith(s) && w.length - s.length >= 4) {
      w = w.slice(0, -s.length);
      break;
    }
  }
  for (const p of PREFIXES) {
    if (w.startsWith(p) && w.length - p.length >= 4) {
      w = w.slice(p.length);
      break;
    }
  }
  return w;
}

export function tokenize(text) {
  return (text.toLowerCase().match(/\p{L}+/gu) ?? []).filter((w) => !STOPWORDS.has(w)).map(stem);
}

const K1 = 1.4;
const B = 0.75;
export const MIN_SCORE = 0.8;
// Minimal sebagian kata kunci pertanyaan harus cocok. Tanpa ini, satu kata yang
// kebetulan sama (mis. "dunia") bisa memunculkan jawaban yang tidak nyambung.
export const MIN_COVERAGE = 0.4;

/** Membuat indeks BM25. Judul dihitung dua kali agar lebih berbobot. */
export function buildIndex(entries) {
  const docs = entries.map((e) => tokenize(`${e.judul} ${e.judul} ${e.kategori} ${e.isi}`));
  const avgLen = docs.reduce((n, d) => n + d.length, 0) / (docs.length || 1);
  const df = new Map();
  for (const d of docs) for (const t of new Set(d)) df.set(t, (df.get(t) ?? 0) + 1);
  return { entries, docs, avgLen, df };
}

/** Mengembalikan entri paling relevan, urut dari skor tertinggi. Kosong jika tidak ada yang cocok. */
export function search(index, query, limit = 4) {
  const terms = [...new Set(tokenize(query))];
  const N = index.entries.length;
  const scored = index.entries.map((entry, i) => {
    const doc = index.docs[i];
    let score = 0;
    let matched = 0;
    for (const t of terms) {
      const tf = doc.filter((x) => x === t).length;
      if (!tf) continue;
      matched += 1;
      const n = index.df.get(t) ?? 0;
      const idf = Math.log(1 + (N - n + 0.5) / (n + 0.5));
      score += (idf * (tf * (K1 + 1))) / (tf + K1 * (1 - B + (B * doc.length) / index.avgLen));
    }
    return { entry, score, coverage: terms.length ? matched / terms.length : 0 };
  });
  return scored
    .filter((s) => s.score >= MIN_SCORE && s.coverage >= MIN_COVERAGE)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

export const NO_DATA_MESSAGE =
  'Saya belum punya data yang cukup tentang itu. Coba tanyakan langsung ke perajin batik atau lembaga kebudayaan di Bengkulu.';

/** Jawaban tanpa AI: menyusun dari entri teratas apa adanya, lengkap dengan penanda sumber. */
export function answerOffline(index, query) {
  const hits = search(index, query, 3);
  if (!hits.length) return { text: NO_DATA_MESSAGE, sources: [] };
  const top = hits[0].score;
  const used = hits.filter((h, i) => i === 0 || h.score >= top * 0.6).slice(0, 2);
  const text = used.map((h, i) => `${h.entry.isi} [${i + 1}]`).join('\n\n');
  return { text, sources: used.map((h) => h.entry) };
}
