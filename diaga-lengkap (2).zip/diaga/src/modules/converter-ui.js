// Antarmuka konverter. Dipasang pada elemen [data-converter]; bagian yang
// tidak ada di markup (mis. rincian di versi mini di beranda) dilewati.
import { convertText, codesOf } from './converter.js';

const FONT_SPEC = '48px "Noto Sans Rejang"';

// Memastikan font aksara benar-benar termuat, supaya tidak muncul kotak kosong.
async function checkFont() {
  if (!document.fonts?.load) return true;
  try {
    const faces = await document.fonts.load(FONT_SPEC, '\uA930');
    return faces.length > 0;
  } catch {
    return false;
  }
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function renderBreakdown(list, result) {
  list.replaceChildren();
  for (const seg of result.segments) {
    if (seg.type !== 'word') continue;
    for (const s of seg.syllables) {
      const item = el('li', 'panel flex items-center gap-4 !p-3');
      if (s.unmapped) {
        item.append(
          el('span', 'unmapped text-2xl', s.latin),
          el('span', 'text-sm text-muted', `${s.latin}: belum ada padanan`),
        );
      } else {
        const meta = el('span', 'flex flex-col');
        meta.append(
          el('span', 'font-semibold', s.latin),
          el('span', 'text-xs text-muted', s.codes.map((c) => `U+${c}`).join(' ')),
        );
        const glyph = el('span', 'rejang text-4xl text-gold-ink', s.glyph);
        glyph.setAttribute('lang', 'rej');
        item.append(glyph, meta);
        item.setAttribute('aria-label', `${s.latin}, kode ${codesOf(s)}`);
      }
      list.append(item);
    }
  }
}

export function mountConverter(root) {
  const input = root.querySelector('[data-conv-input]');
  const output = root.querySelector('[data-conv-output]');
  if (!input || !output) return;

  const breakdown = root.querySelector('[data-conv-breakdown]');
  const notice = root.querySelector('[data-conv-notice]');
  const fontMsg = root.querySelector('[data-conv-font]');
  const copyBtn = root.querySelector('[data-conv-copy]');
  const subBox = root.querySelector('[data-conv-sub]');
  // Mode demo (?demo=1): isi contoh otomatis supaya demo 3 menit langsung berjalan.
  if (new URLSearchParams(location.search).get('demo') === '1') input.value = 'Rejang Lebong';
  let lastGlyph = '';

  const update = () => {
    const result = convertText(input.value, { substitute: Boolean(subBox?.checked) });
    lastGlyph = result.glyph;
    output.textContent = result.glyph || '\u00a0';

    if (breakdown) renderBreakdown(breakdown, result);

    if (notice) {
      const missing = [
        ...new Set(
          result.segments
            .filter((s) => s.type === 'word')
            .flatMap((s) => s.syllables.filter((y) => y.unmapped).map((y) => y.latin)),
        ),
      ];
      notice.textContent = missing.length
        ? `Belum ada padanan Rejang untuk huruf: ${missing.join(', ')}. Huruf itu ditampilkan apa adanya.`
        : '';
    }
  };

  // Hasil langsung muncul saat mengetik. aria-live polite menggabungkan pengumuman untuk pembaca layar.
  input.addEventListener('input', update);
  subBox?.addEventListener('change', update);

  root.querySelectorAll('[data-example]').forEach((btn) => {
    btn.addEventListener('click', () => {
      input.value = btn.dataset.example;
      update();
      input.focus();
    });
  });

  copyBtn?.addEventListener('click', async () => {
    const original = copyBtn.textContent;
    try {
      await navigator.clipboard.writeText(lastGlyph);
      copyBtn.textContent = 'Tersalin';
    } catch {
      copyBtn.textContent = 'Gagal menyalin';
    }
    setTimeout(() => (copyBtn.textContent = original), 1600);
  });

  update();

  checkFont().then((ok) => {
    if (ok || !fontMsg) return;
    fontMsg.textContent =
      'Font aksara Rejang gagal dimuat, jadi karakter mungkin tampil sebagai kotak. Muat ulang halaman atau coba peramban lain.';
    fontMsg.hidden = false;
  });
}

export function initConverters() {
  document.querySelectorAll('[data-converter]').forEach(mountConverter);
}
