// Tombol tema: gelap/terang, disimpan di localStorage (opsional, boleh gagal).
const KEY = 'diaga-theme';

const systemPrefersLight = () => window.matchMedia('(prefers-color-scheme: light)').matches;

function currentTheme() {
  return (
    document.documentElement.getAttribute('data-theme') ?? (systemPrefersLight() ? 'light' : 'dark')
  );
}

function label(button) {
  const next = currentTheme() === 'dark' ? 'terang' : 'gelap';
  button.textContent = currentTheme() === 'dark' ? 'Terang' : 'Gelap';
  button.setAttribute('aria-label', `Ganti ke tema ${next}`);
}

export function initTheme() {
  const button = document.querySelector('[data-theme-toggle]');
  if (!button) return;
  label(button);
  button.addEventListener('click', () => {
    const next = currentTheme() === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try {
      localStorage.setItem(KEY, next);
    } catch {
      /* tidak masalah, tema tetap berlaku untuk sesi ini */
    }
    label(button);
  });
}
