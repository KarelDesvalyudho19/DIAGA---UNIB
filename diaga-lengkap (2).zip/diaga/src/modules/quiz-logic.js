// Logika kuis: kotak Leitner sederhana (3 kotak) tanpa DOM, supaya mudah diuji.
import aksara from '../data/aksara.json';
import { convertText } from './converter.js';

export const MODES = {
  'bunyi-ke-huruf': 'Tebak huruf dari bunyi',
  'huruf-ke-bunyi': 'Tebak bunyi dari huruf',
  'aksara-ke-kata': 'Baca aksara, ketik katanya',
};

// Kata yang tidak memuat huruf tanpa padanan, jadi jawabannya tidak ambigu.
export const WORDS = ['bengkulu', 'rejang', 'kaganga', 'batik', 'curup', 'nama', 'buku', 'kota'];

const WEIGHT = { 1: 5, 2: 3, 3: 1 }; // makin tinggi kotak, makin jarang muncul
const toChar = (hex) => String.fromCodePoint(parseInt(hex, 16));

export const emptyState = () => ({ items: {}, streak: 0, best: 0, total: 0, correct: 0 });

export const boxOf = (state, id) => state.items[id]?.box ?? 1;

export function itemsFor(mode) {
  return mode === 'aksara-ke-kata' ? WORDS.map((w) => `kata:${w}`) : aksara.huruf.map((h) => h.id);
}

/** Memilih butir soal berbobot, menghindari yang baru saja keluar. */
export function pickItem(mode, state, rng = Math.random, lastId = null) {
  const pool = itemsFor(mode).filter((id) => id !== lastId);
  const weights = pool.map((id) => WEIGHT[boxOf(state, id)]);
  let r = rng() * weights.reduce((a, b) => a + b, 0);
  for (let i = 0; i < pool.length; i++) {
    r -= weights[i];
    if (r <= 0) return pool[i];
  }
  return pool[pool.length - 1];
}

function shuffle(list, rng) {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function makeQuestion(mode, state, rng = Math.random, lastId = null) {
  const itemId = pickItem(mode, state, rng, lastId);

  if (mode === 'aksara-ke-kata') {
    const word = itemId.slice(5);
    const r = convertText(word);
    const parts = r.segments[0].syllables.map((s) => s.latin).join('·');
    return {
      mode,
      itemId,
      prompt: 'Apa kata yang tertulis ini?',
      glyph: r.glyph,
      answer: word,
      explanation: `Kata itu "${word}", dibaca ${parts}.`,
    };
  }

  const letter = aksara.huruf.find((h) => h.id === itemId);
  const others = shuffle(
    aksara.huruf.filter((h) => h.id !== itemId),
    rng,
  ).slice(0, 3);
  const options = shuffle([letter, ...others], rng).map((h) => ({
    value: h.id,
    label: h.id,
    glyph: toChar(h.kode),
  }));
  const explanation = `"${letter.id}" ditulis ${toChar(letter.kode)} (U+${letter.kode}). ${letter.bunyi}`;

  if (mode === 'bunyi-ke-huruf') {
    return {
      mode,
      itemId,
      prompt: `Huruf mana yang dibaca "${letter.id}"?`,
      options,
      answer: letter.id,
      explanation,
    };
  }
  return {
    mode,
    itemId,
    prompt: 'Bagaimana huruf ini dibaca?',
    glyph: toChar(letter.kode),
    options,
    answer: letter.id,
    explanation,
  };
}

export function isCorrect(question, given) {
  return given.trim().toLowerCase() === question.answer;
}

/** Mengembalikan state baru: benar naik satu kotak, salah kembali ke kotak 1. */
export function grade(state, itemId, correct) {
  const prev = state.items[itemId] ?? { box: 1, seen: 0, right: 0 };
  const box = correct ? Math.min(3, prev.box + 1) : 1;
  const streak = correct ? state.streak + 1 : 0;
  return {
    items: {
      ...state.items,
      [itemId]: { box, seen: prev.seen + 1, right: prev.right + (correct ? 1 : 0) },
    },
    streak,
    best: Math.max(state.best, streak),
    total: state.total + 1,
    correct: state.correct + (correct ? 1 : 0),
  };
}
